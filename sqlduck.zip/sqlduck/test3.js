/* Scale test: can the page index actually hold a multi-GB file's worth of
   pages, and does it stay correct past the 4 GB offset boundary? */
const fs=require('fs'),vm=require('vm');
const js=fs.readFileSync((process.env.SQLDUCK || './sqlduck.html'),'utf8').match(/<script>([\s\S]*?)<\/script>/)[1];
const mkEl=()=>new Proxy({},{get:(t,k)=>{
 if(k==='classList')return{toggle(){},add(){},remove(){},contains(){return false}};
 if(k==='options'||k==='selectedOptions')return{length:1,0:{text:''}};
 if(k==='style'||k==='dataset')return{};
 if(k==='querySelector')return()=>mkEl(); if(k==='querySelectorAll')return()=>[];
 if(['appendChild','add','focus','click'].includes(k))return()=>{};
 if(k==='value')return'0'; if(k==='checked')return false;
 if(typeof k==='string'&&k.startsWith('on'))return null; return mkEl();},set:()=>true});
const ctx={console,navigator:{},location:{protocol:'http:'},confirm:()=>true,alert(){},
 document:{querySelector:()=>mkEl(),querySelectorAll:()=>[],addEventListener(){},createElement:()=>mkEl()},
 window:{addEventListener(){},open:()=>null},setTimeout,clearTimeout,Blob:class{},
 URL:{createObjectURL(){},revokeObjectURL(){}},FileReader:class{}};
vm.createContext(ctx); vm.runInContext(js,ctx);

let pass=0,fail=0;
const check=(n,c,x)=>{c?(pass++,console.log('  PASS  '+n)):(fail++,console.log('  FAIL  '+n+(x!==undefined?'  -> '+x:'')));};

const N = 1400000;                              // ~11.5 GB of 8 KB pages
console.log('indexing '+N.toLocaleString()+' pages (~'+(N*8192/1073741824).toFixed(1)+' GB of file)…');
const t0=Date.now();
const r=vm.runInContext(`
  (function(){
    const px=newPageIndex();
    for(let i=0;i<${N};i++){
      pxPush(px,{pageId:i,fileId:1,type:(i%7===0?2:1),level:0,indexId:i%3,
                 objId:1000+(i%50),slotCnt:20,freeCnt:100,ghostRecCnt:0}, i*8192);
    }
    const last=pxGet(px,px.n-1);
    const sel=pxSelect(px,pxLeafOf({obj:1000,ix:0}),50);
    return { n:px.n, cap:px.cap,
             lastOff:last.off, lastId:last.id, lastType:last.t,
             selTotal:sel.total, selRows:sel.rows.length,
             bytesUsed: px.cap*(8+4+4+2+1+1+2+2+2+2) };
  })()`,ctx);
const ms=Date.now()-t0;

console.log('\n== scale ==');
check('all pages indexed', r.n===N, r.n);
check('index survives past 4 GB offset', r.lastOff===(N-1)*8192 && r.lastOff>4294967296, r.lastOff);
check('last page id intact', r.lastId===N-1, r.lastId);
check('page type preserved', r.lastType===((N-1)%7===0?2:1), r.lastType);
check('filter finds the right subset', r.selTotal>0 && r.selRows===50, [r.selTotal,r.selRows].join('/'));
check('memory under 100 MB', r.bytesUsed < 100*1024*1024, (r.bytesUsed/1048576).toFixed(0)+' MB');
check('indexing under 30 s', ms < 30000, ms+' ms');
console.log('  ('+(r.bytesUsed/1048576).toFixed(0)+' MB for '+r.n.toLocaleString()+' pages, '+ms+' ms)');

console.log('\n== settings ==');
const html=fs.readFileSync((process.env.SQLDUCK || './sqlduck.html'),'utf8');
check('entire file is the default range', /<option value="0" selected>entire file<\/option>/.test(html));
check('10 GB threshold defined', /HUGE_FILE = 10\*1024\*1024\*1024/.test(html));
check('size banner element present', html.includes('id="sizeWarn"'));
check('scan asks before a huge read', html.includes('if(limit>HUGE_FILE&&!S.hugeAck)'));

console.log('\n'+(fail?'FAILED '+fail+' / '+(pass+fail):'ALL '+pass+' CHECKS PASSED'));
process.exit(fail?1:0);
