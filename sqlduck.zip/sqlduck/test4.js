/* =====================================================================
   Column resizing — width arithmetic, clamping, persistence, reset.
   There is no layout engine here, so this drives makeResizable() against
   a hand-rolled DOM that implements exactly the operations it uses and
   reports whatever natural widths the test asks for.
   ===================================================================== */
const fs = require('fs'), vm = require('vm');
const HTML = process.env.SQLDUCK || './sqlduck.html';

/* ---------------- minimal DOM ---------------- */
class N {
  constructor(tag){
    this.tagName = tag.toUpperCase();
    this.children = []; this.parentNode = null;
    this.style = {}; this._cls = new Set(); this._on = {};
    this._natural = 100; this.title = '';
    const self = this;
    this.classList = {
      add:c=>self._cls.add(c), remove:c=>self._cls.delete(c),
      contains:c=>self._cls.has(c), toggle:c=>self._cls.has(c)?self._cls.delete(c):self._cls.add(c)
    };
  }
  get className(){ return [...this._cls].join(' '); }
  set className(v){ this._cls = new Set(String(v).split(/\s+/).filter(Boolean)); }
  appendChild(n){ n.parentNode = this; this.children.push(n); return n; }
  insertBefore(n, ref){
    n.parentNode = this;
    const i = ref ? this.children.indexOf(ref) : -1;
    if (i < 0) this.children.push(n); else this.children.splice(i, 0, n);
    return n;
  }
  removeChild(n){ const i = this.children.indexOf(n); if (i >= 0) this.children.splice(i,1); n.parentNode = null; return n; }
  get firstChild(){ return this.children[0] || null; }
  _walk(f){ for (const c of this.children){ f(c); c._walk(f); } }
  querySelector(sel){
    let hit = null;
    this._walk(n => {
      if (hit) return;
      if (sel.startsWith('.')) { if (n._cls.has(sel.slice(1))) hit = n; }
      else if (n.tagName === sel.toUpperCase()) hit = n;
    });
    return hit;
  }
  getBoundingClientRect(){ return { width: this._natural, left: 0 }; }
  addEventListener(t, f){ (this._on[t] = this._on[t] || []).push(f); }
  removeEventListener(t, f){ if (this._on[t]) this._on[t] = this._on[t].filter(x => x !== f); }
  fire(t, ev){
    const e = Object.assign({ preventDefault(){}, stopPropagation(){}, pointerId: 1 }, ev);
    (this._on[t] || []).slice().forEach(f => f(e));
  }
  /* table-ish helpers */
  get tHead(){ return this.querySelector('thead'); }
  get rows(){ return this.children.filter(c => c.tagName === 'TR'); }
  get cells(){ return this.children.filter(c => c.tagName === 'TH' || c.tagName === 'TD'); }
}

const body = new N('body');
const ctx = {
  console,
  document: { createElement: t => new N(t), body,
              querySelector: () => new N('div'), querySelectorAll: () => [], addEventListener(){} },
  window:{ addEventListener(){}, devicePixelRatio:2 },
  navigator:{}, location:{ protocol:'http:' }, confirm:()=>true, alert(){},
  setTimeout, clearTimeout, Blob:class{}, URL:{createObjectURL(){},revokeObjectURL(){}},
  FileReader:class{}, Option:class{ constructor(t,v){ this.text=t; this.value=v; } },
};
ctx.globalThis = ctx;
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(HTML,'utf8').match(/<script>([\s\S]*?)<\/script>/)[1], ctx, {filename:'sqlduck.js'});
const g = n => vm.runInContext(n, ctx);

/* ---------------- helpers ---------------- */
function buildTable(naturals){
  const t = new N('table'), thead = new N('thead'), tr = new N('tr');
  naturals.forEach(w => { const th = new N('th'); th._natural = w; tr.appendChild(th); });
  thead.appendChild(tr); t.appendChild(thead);
  const tb = new N('tbody'); t.appendChild(tb);
  return t;
}
const colsOf = t => (t.querySelector('colgroup') || { children: [] }).children.map(c => parseFloat(c.style.width));
const gripOf = (t, i) => t.tHead.rows[0].cells[i].querySelector('.colgrip');
function drag(t, i, dx){
  const grip = gripOf(t, i);
  grip.fire('pointerdown', { clientX: 500 });
  grip.fire('pointermove', { clientX: 500 + dx });
  grip.fire('pointerup', { clientX: 500 + dx });
}

let pass = 0, fail = 0;
const check = (id, what, cond, extra) => {
  cond ? (pass++, console.log('  PASS  ' + id + '  ' + what))
       : (fail++, console.log('  FAIL  ' + id + '  ' + what + (extra !== undefined ? '  -> ' + JSON.stringify(extra) : '')));
};

/* ---------------- R — setup ---------------- */
console.log('\nR — COLGROUP SETUP');
const t1 = buildTable([50, 900, 120, 90]);          // 900 mimics a wide datetime column
g('makeResizable')(t1, 'orders');
check('R1','colgroup created with one col per header', colsOf(t1).length === 4, colsOf(t1));
check('R2','natural widths adopted', colsOf(t1)[2] === 120 && colsOf(t1)[3] === 90, colsOf(t1));
check('R3','an over-wide column is capped at 340', colsOf(t1)[1] === 340, colsOf(t1)[1]);
check('R4','a narrow column is floored at 44', colsOf(t1)[0] === 50, colsOf(t1)[0]);
check('R5','table switched to fixed layout', t1._cls.has('rsz'));
check('R6','table width equals the sum of its columns', t1.style.width === '600px', t1.style.width);
check('R7','every header got a grip', [0,1,2,3].every(i => !!gripOf(t1, i)));
check('R8','grips are not duplicated on a second call',
      (g('makeResizable')(t1,'orders'), t1.tHead.rows[0].cells[0].children.filter(c => c._cls.has('colgrip')).length === 1));

/* ---------------- R — dragging ---------------- */
console.log('\nR — DRAG ARITHMETIC');
drag(t1, 1, 120);
check('R9','dragging right widens by the pointer delta', colsOf(t1)[1] === 460, colsOf(t1)[1]);
check('R10','table width follows the change', t1.style.width === '720px', t1.style.width);
drag(t1, 1, -200);
check('R11','dragging left narrows', colsOf(t1)[1] === 260, colsOf(t1)[1]);
drag(t1, 0, -500);
check('R12','a column cannot be dragged below the 44 px minimum', colsOf(t1)[0] === 44, colsOf(t1)[0]);
check('R13','neighbouring columns are unaffected by a drag', colsOf(t1)[2] === 120 && colsOf(t1)[3] === 90, colsOf(t1));

console.log('\nR — DRAG STATE');
const grip = gripOf(t1, 2);
grip.fire('pointerdown', { clientX: 100 });
check('R14','body marked while dragging, so the cursor stays consistent', body._cls.has('resizing'));
check('R15','the active grip is highlighted', grip._cls.has('on'));
grip.fire('pointerup', { clientX: 100 });
check('R16','body class cleared on release', !body._cls.has('resizing'));
check('R17','highlight cleared on release', !grip._cls.has('on'));
grip.fire('pointermove', { clientX: 9999 });
check('R18','moves after release are ignored', colsOf(t1)[2] === 120, colsOf(t1)[2]);

/* ---------------- R — double-click to fit ---------------- */
console.log('\nR — DOUBLE-CLICK TO FIT');
t1.tHead.rows[0].cells[3]._natural = 210;
gripOf(t1, 3).fire('dblclick', {});
check('R19','fit sizes to content plus padding', colsOf(t1)[3] === 224, colsOf(t1)[3]);
check('R20','fixed layout restored after measuring', t1._cls.has('rsz'));
t1.tHead.rows[0].cells[3]._natural = 5000;
gripOf(t1, 3).fire('dblclick', {});
check('R21','fit is capped at 600 px', colsOf(t1)[3] === 600, colsOf(t1)[3]);

/* ---------------- R — persistence ---------------- */
console.log('\nR — PERSISTENCE ACROSS RENDERS');
const widths = colsOf(t1);
const t2 = buildTable([50, 900, 120, 90]);
g('makeResizable')(t2, 'orders');
check('R22','widths survive a re-render of the same table', JSON.stringify(colsOf(t2)) === JSON.stringify(widths), colsOf(t2));
const t3 = buildTable([50, 900, 120, 90]);
g('makeResizable')(t3, 'customers');
check('R23','a different table starts from its own natural widths', colsOf(t3)[1] === 340, colsOf(t3)[1]);
check('R24','tables do not share stored widths', colsOf(t3)[0] === 50, colsOf(t3)[0]);

console.log('\nR — RESET');
g('resetWidths')('orders', t2);
check('R25','reset returns columns to their natural widths', colsOf(t2)[1] === 340 && colsOf(t2)[0] === 50, colsOf(t2));
check('R26','reset leaves exactly one colgroup', t2.children.filter(c => c.tagName === 'COLGROUP').length === 1);
check('R27','reset does not duplicate grips', t2.tHead.rows[0].cells[1].children.filter(c => c._cls.has('colgrip')).length === 1);
const t4 = buildTable([50, 900, 120, 90]);
g('makeResizable')(t4, 'orders');
check('R28','reset cleared the stored widths too', colsOf(t4)[1] === 340, colsOf(t4)[1]);

/* ---------------- R — robustness ---------------- */
console.log('\nR — ROBUSTNESS');
const safe = fn => { try { fn(); return true; } catch (e) { return 'threw: ' + e.message; } };
check('R29','a null table is ignored', safe(() => g('makeResizable')(null, 'x')) === true);
check('R30','a table with no thead is ignored', safe(() => g('makeResizable')(new N('table'), 'x')) === true);
check('R31','an empty header row is ignored', safe(() => {
  const t = new N('table'), th = new N('thead'); th.appendChild(new N('tr')); t.appendChild(th);
  g('makeResizable')(t, 'x');
}) === true);
check('R32','resetWidths tolerates a missing table', safe(() => g('resetWidths')('nope', null)) === true);
check('R33','a header with zero measurable width still gets a usable default', (() => {
  const t = buildTable([0, 0]); g('makeResizable')(t, 'zero');
  return colsOf(t).every(w => w >= 44);
})(), colsOf(buildTable([0,0])));

console.log('\n' + (fail ? 'FAILED ' + fail + ' / ' + (pass + fail) : 'ALL ' + pass + ' CHECKS PASSED'));
process.exit(fail ? 1 : 0);
