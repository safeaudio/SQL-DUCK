# SQLDUCK — Self-Test Procedure (STP)

| | |
|---|---|
| **Component** | `sqlduck.html` — browser inspector for SQL Server MDF / LDF / BAK |
| **Fixture** | `northwind_sim.bak` (120 KB, 14 pages, MTF-wrapped) |
| **Harness** | `stp.js` (Node ≥ 18, no dependencies) |
| **Run date** | 2026-08-25 |
| **Result** | **101 / 101 PASS** |

## 1. Purpose

Verify end to end that the tool reads a SQL Server backup file, recovers the
object catalogue without any hardcoded on-disk layout, decodes table rows into
values a person can read, reassembles stored procedure source, and renders all
of it without corrupting the data on the way to the screen.

## 2. Scope note — read this first

The sandbox that produced this document has no network egress, so the real
Microsoft sample backup could not be downloaded. `northwind_sim.bak` is a
**generated** file, not a Microsoft artefact. It is faithful where it matters:

* real MTF container — `TAPE` / `SSET` / `VOLB` / `DIRB` / `FILE` / `MSDA` / `ESET` / `EOTM` blocks
* real 8 KB pages with correct 96-byte headers, slot arrays and record format
* the genuine Northwind schema — table names, column names, column order, SQL types
* system catalogue laid out as `sysschobjs` / `syscolpars` / `sysobjvalues`

It is **not** faithful in three respects, and these are the gaps a run against a
real backup would close:

1. no LOB (text/image) pages — off-row values are not exercised
2. no B-tree index pages, no IAM / GAM / PFS allocation structures
3. no backup compression or encryption

`sysschobjs` is deliberately written with an **unusual layout** (44-byte fixed
portion, type code at offset 17) that matches no SQL Server release. Recovery
must derive it from the data. A fixture using textbook offsets would let a
hardcoded reader pass.

## 3. Running it against the real database

```bash
# 1. get the real Microsoft sample (about 1 GB)
curl -L -o AdventureWorks2019.bak \
  https://github.com/Microsoft/sql-server-samples/releases/download/adventureworks/AdventureWorks2019.bak

# 2. serve the tool (file:// is blocked by Chrome's origin policy)
python3 -m http.server 8766
# open http://localhost:8766/sqlduck.html, drop the .bak in, Build object tree

# 3. re-run this STP against the fixture at any time
node stp.js          # human readable
node stp.js --md     # this results table
```

Expect AdventureWorks to exercise cases the fixture cannot: `Production.Document`
holds `varbinary(max)`, several tables carry `xml` columns, and `uniqueidentifier`
`rowguid` columns appear throughout. Compare the recovered tree against
`sys.tables` / `sys.columns` on a restored copy before trusting it on anything real.

## 4. Preconditions

* `sqlduck.html` and `northwind_sim.bak` in the same folder as `stp.js`
* Node 18 or later on PATH
* For manual GUI checks: Chrome, served over `http://localhost`, never `file://`

## 5. Fixture contents

| Table | Columns | Fixed bytes | Variable cols | Rows |
|---|---|---|---|---|
| Categories | 4 | 4 | 3 | 4 |
| Customers | 11 | 10 | 10 | 5 |
| Employees | 11 | 24 | 7 | 3 |
| Products | 10 | 27 | 2 | 5 |
| Orders | 11 | 54 | 3 | 4 |
| Order Details | 5 | 22 | 0 | 6 |
| Shippers | 3 | 4 | 2 | 3 |
| Suppliers | 6 | 4 | 5 | 2 |

Modules: 2 views, 4 stored procedures. `SalesByCategory` is padded past 4 000
characters so its definition spans several `sysobjvalues` chunks, stored out of
order to force reassembly by chunk number.

Deliberately seeded edge cases:

| Where | Value | Exercises |
|---|---|---|
| `Customers.CompanyName` (BENJR) | `Ben & Jerry's <Nordic> "AB"` | HTML escaping |
| `Customers.ContactName` (BENJR) | `Chris <b>Bold</b>` | markup must not go live |
| `Customers.Address` (BENJR) | `XXX` + 100 × `&` | truncation must not split an entity |
| `Customers.ContactName` (ANATR) | `Ana\u0007Trujillo` | control character sanitising |
| `Customers.Region` (ANATR) | `''` | empty string vs NULL |
| `Customers.Region` (ALFKI) | NULL | NULL rendering |
| `Orders.ShippedDate` (10250) | NULL | NULL in a fixed-length column |
| `Employees.ReportsTo` (2) | NULL | NULL int |
| `Categories.Description` | NULL | NULL LOB column |
| Table name `Order Details` | — | space in an identifier |
| Proc name `Ten Most Expensive Products` | — | spaces in a module name |
| Allocation unit `54:0` | decoy `sysidxstats` | must not be mistaken for `syscolpars` |

## 6. Defects found and fixed

### 6.1 First automated run — 7 failures of 85

All were real, all are fixed.

| ID | Defect | Fix |
|---|---|---|
| E13, E14 | `real` columns printed as `0.20000000298023224` — float32 has ~7 significant digits, so 17 were being shown | round to 7 significant digits on display |
| G4 | value truncation ran **after** HTML escaping, so a 300-character cut could land inside `&amp;` and emit a broken entity | truncate the raw value, then escape |
| G6 | empty string and NULL both rendered as nothing — indistinguishable in a QA context | NULL stays `NULL`, empty string renders `(empty)` |
| G7 | control characters passed straight into the cell and corrupted layout | tabs/newlines to space, other control bytes to `·` |
| G8 | no row numbers, so a specific row could not be referred to | sticky `#` column |
| G19 | an allocation unit with no rows rendered a bare header row and looked broken | explicit empty state |

Three further GUI defects were fixed in the same pass, found by review rather
than by an assertion:

| Defect | Fix |
|---|---|
| Tree filter searched only expanded nodes, so filtering with folders shut found nothing | filter builds the top three levels, then reveals each match with its ancestors |
| Page-map canvas ignored `devicePixelRatio` — blurred on a Retina display | back the canvas at device resolution and scale the context |
| PAGES tab type/allocation dropdowns kept the previous file's entries after opening a second file | reset on load |

### 6.2 Second round — found from a screenshot of the running app

Four defects that only appear once real data is on screen. Checks G21–G30 were
added for them, and 7 of those 10 fail against the previous build, confirming
they catch the regression rather than restating the fix.

| ID | Defect | Cause | Fix |
|---|---|---|---|
| G21–G23 | with a wide table selected the **whole page** scrolled sideways and the toolbar ran off the right edge | `grid-template-columns:360px 1fr` — `1fr` means `minmax(auto,1fr)`, and an `auto` minimum is min-content, so a wide grid pushed the layout wider than the window | `minmax(0,1fr)` on the track, `min-width:0` on the detail pane, so scrolling stays inside the data grid |
| G24 | the `#` column stayed put when scrolling right but its header slid away, leaving the heading row misaligned | only the cells were `position:sticky;left:0`, not the header cell | header cell made sticky on the same axis |
| G25, G26 | `CustomerID` displayed as `CUSTOMERID`, `nchar(5)` as `NCHAR(5)` | a global `th{text-transform:uppercase}` meant for section headings also hit the data grid | uppercase scoped away from `.grid th`; identifier casing is often the thing being checked, so it has to survive to the screen |
| G27–G30 | clipped cells and tree labels ended in `…` with no way to reach the rest | cells are `nowrap` with `text-overflow:ellipsis` and nothing else | full value carried in a `title` tooltip on cells over 40 characters and on every tree row; tooltip text is escaped and control-stripped |

The tree pane is also resizable now (drag its right edge), since allocation-unit
labels such as `alloc unit 1093578934:0` clip at the default 360 px.

### 6.3 Third round — column width control

Requested after seeing `dbo.Orders` on screen: three `datetime` columns each
consumed roughly 340 px of natural width while `ShipName` was pushed off the
right edge, and there was no way to rebalance them.

Auto table layout sizes columns purely by content, so the fix is to measure
those natural widths once, freeze them into a `<colgroup>`, switch the table to
`table-layout:fixed`, and attach a drag grip to the trailing edge of every
header. Behaviour:

* drag a column edge to resize, with a 44 px floor
* double-click an edge to fit that column to its content, capped at 600 px
* **Reset column widths** restores the measured defaults
* widths are remembered per table for the session, so paging away and back keeps them
* applied to the data grid, the PAGES table and the TEXT table

A defect was found while building this: the stylesheet for the grips was lost in
an editing step, so the drag handles existed in the DOM with no cursor, no
divider and no absolute positioning — invisible and unusable. Checks G34–G36
assert the CSS rules directly and caught it.

Column resizing has its own suite (`test4.js`, 33 checks) driving the real
`makeResizable()` against a purpose-built DOM, since there is no layout engine
in the harness. It covers width clamping, drag arithmetic, neighbour isolation,
release handling, double-click fit, per-table persistence, reset, and six
malformed-input cases.

## 7. Results

| ID | Check | Expected | Actual | Result |
|---|---|---|---|---|
| **A — FILE HANDLING** | | | | |
| A1 | MTF backup recognised from the TAPE signature | `bak` | `bak` | PASS |
| A2 | tape blocks listed (TAPE/SSET/FILE) | `true` | `true` | PASS |
| A3 | MSDA data stream identified | `true` | `true` | PASS |
| A4 | backup set names the database | `true` | `true` | PASS |
| **B — PAGE SCAN** | | | | |
| B1 | every 8 KB page inside the MTF stream found | `14` | `14` | PASS |
| B2 | all pages classified as data pages | `14` | `14` | PASS |
| B3 | scan covered the whole file | `false` | `false` | PASS |
| B4 | page index did not overflow | `false` | `false` | PASS |
| **C — OBJECT CATALOGUE** | | | | |
| C1 | schema recovery reports success | `true` | `true` | PASS |
| C2 | user tables recovered | `8` | `8` | PASS |
| C3 | views recovered | `2` | `2` | PASS |
| C4 | stored procedures recovered | `4` | `4` | PASS |
| C5 | table name containing a space is intact | `true` | `true` | PASS |
| C6 | dbo schema resolved from schema_id | `dbo.Customers` | `dbo.Customers` | PASS |
| C7 | foreign key linked to its parent table | `Orders` | `Orders` | PASS |
| C8 | decoy sysidxstats unit rejected | `true` | `true` | PASS |
| C9 | column set verified against on-disk row shapes | `true` | `true` | PASS |
| **D — COLUMN RECOVERY** | | | | |
| D1 | columns of Categories | `CategoryID,CategoryName,Description,Picture` | `CategoryID,CategoryName,Description,Picture` | PASS |
| D2 | columns of Customers | `CustomerID,CompanyName,ContactName,ContactTitl…` | `CustomerID,CompanyName,ContactName,ContactTitl…` | PASS |
| D3 | columns of Employees | `EmployeeID,LastName,FirstName,Title,TitleOfCou…` | `EmployeeID,LastName,FirstName,Title,TitleOfCou…` | PASS |
| D4 | columns of Products | `ProductID,ProductName,SupplierID,CategoryID,Qu…` | `ProductID,ProductName,SupplierID,CategoryID,Qu…` | PASS |
| D5 | columns of Orders | `OrderID,CustomerID,EmployeeID,OrderDate,Requir…` | `OrderID,CustomerID,EmployeeID,OrderDate,Requir…` | PASS |
| D6 | columns of Order Details | `OrderID,ProductID,UnitPrice,Quantity,Discount` | `OrderID,ProductID,UnitPrice,Quantity,Discount` | PASS |
| D7 | columns of Shippers | `ShipperID,CompanyName,Phone` | `ShipperID,CompanyName,Phone` | PASS |
| D8 | columns of Suppliers | `SupplierID,CompanyName,ContactName,City,Countr…` | `SupplierID,CompanyName,ContactName,City,Countr…` | PASS |
| D9 | nchar(5) width reported in characters | `nchar(5)` | `nchar(5)` | PASS |
| D10 | nvarchar(40) width reported in characters | `nvarchar(40)` | `nvarchar(40)` | PASS |
| D11 | money type identified | `money` | `money` | PASS |
| D12 | real type identified | `real` | `real` | PASS |
| D13 | bit type identified | `bit` | `bit` | PASS |
| D14 | ntext LOB type identified | `ntext` | `ntext` | PASS |
| D15 | smallint type identified | `smallint` | `smallint` | PASS |
| **E — TABLE CONTENT (CLEAR VALUE DISPLAY)** | | | | |
| E1 | Products row count | `5` | `5` | PASS |
| E2 | int value | `1` | `1` | PASS |
| E3 | nvarchar value | `Chai` | `Chai` | PASS |
| E4 | money value | `18.0000` | `18.0000` | PASS |
| E5 | money value with cents | `21.3500` | `21.3500` | PASS |
| E6 | large money value | `263.5000` | `263.5000` | PASS |
| E7 | smallint value | `39` | `39` | PASS |
| E8 | bit value false | `0` | `0` | PASS |
| E9 | bit value true | `1` | `1` | PASS |
| E10 | datetime value | `1996-07-04 00:00:00.000` | `1996-07-04 00:00:00.000` | PASS |
| E11 | NULL datetime reported as null | `null` | `null` | PASS |
| E12 | nchar padded value trimmed | `ALFKI` | `ALFKI` | PASS |
| E13 | real value shown without float noise | `0.15` | `0.15` | PASS |
| E14 | real value 0.2 shown cleanly | `0.2` | `0.2` | PASS |
| E15 | real zero | `0` | `0` | PASS |
| E16 | NULL int reported as null | `null` | `null` | PASS |
| E17 | NULL nvarchar reported as null | `null` | `null` | PASS |
| E18 | empty string is NOT reported as null | `` | `` | PASS |
| E19 | NULL LOB (ntext) column reported as null | `null` | `null` | PASS |
| E20 | row with a space in the table name reads | `6` | `6` | PASS |
| E21 | Employees datetime | `1968-12-08 00:00:00.000` | `1968-12-08 00:00:00.000` | PASS |
| **F — STORED PROCEDURE SOURCE** | | | | |
| F1 | definitions recovered for every module | `6` | `6` | PASS |
| F2 | source of Alphabetical list of products byte-i… | `true` | `true` | PASS |
| F3 | source of Current Product List byte-identical | `true` | `true` | PASS |
| F4 | source of CustOrderHist byte-identical | `true` | `true` | PASS |
| F5 | source of CustOrdersDetail byte-identical | `true` | `true` | PASS |
| F6 | source of Ten Most Expensive Products byte-ide… | `true` | `true` | PASS |
| F7 | source of SalesByCategory byte-identical | `true` | `true` | PASS |
| F8 | multi-chunk definition reassembled in order | `true` | `true` | PASS |
| F9 | keywords highlighted | `true` | `true` | PASS |
| F10 | bracketed identifiers highlighted | `true` | `true` | PASS |
| F11 | block comment highlighted | `true` | `true` | PASS |
| F12 | string literal highlighted | `true` | `true` | PASS |
| **G — RENDERING AND GUI** | | | | |
| G1 | grid renders the table name | `true` | `true` | PASS |
| G2 | HTML metacharacters in data are escaped | `true` | `true` | PASS |
| G3 | no live markup leaked from data | `true` | `true` | PASS |
| G4 | truncation never splits an HTML entity | `true` | `true` | PASS |
| G5 | NULL rendered distinctly | `true` | `true` | PASS |
| G6 | empty string distinguishable from NULL | `true` | `true` | PASS |
| G7 | control characters replaced for display | `true` | `true` | PASS |
| G8 | row numbers shown | `true` | `true` | PASS |
| G9 | column type shown under each header | `true` | `true` | PASS |
| G10 | procedure detail shows a definition block | `true` | `true` | PASS |
| G11 | copy and download offered | `true` | `true` | PASS |
| G12 | tree exposes the expected folders | `true` | `true` | PASS |
| G13 | Tables node reports the right count | `8` | `8` | PASS |
| G14 | Data node comes first under a table | `true` | `true` | PASS |
| G15 | Columns node populated for a table with a spac… | `5` | `5` | PASS |
| G16 | ribbon survives a zero-width canvas | `true` | `true` | PASS |
| G17 | storage tab renders | `true` | `true` | PASS |
| G18 | diagnostics renders candidate table | `true` | `true` | PASS |
| G31 | grid offers a reset for column widths | `true` | `true` | PASS |
| G32 | resize affordance is explained next to the gri… | `true` | `true` | PASS |
| G33 | header cells can host an absolutely positioned… | `true` | `true` | PASS |
| G34 | a grip is drawn on the trailing edge of a head… | `true` | `true` | PASS |
| G35 | pointer drags are not swallowed by touch scrol… | `true` | `true` | PASS |
| G36 | resized tables use fixed layout so widths are … | `true` | `true` | PASS |
| G21 | explorer column can shrink below its content w… | `true` | `true` | PASS |
| G22 | detail pane allows shrinking inside the grid t… | `true` | `true` | PASS |
| G23 | page cannot scroll horizontally as a whole | `true` | `true` | PASS |
| G24 | row-number header is sticky horizontally, like… | `true` | `true` | PASS |
| G25 | data grid headers keep their real identifier c… | `true` | `true` | PASS |
| G26 | column name reaches the grid unaltered | `true` | `true` | PASS |
| G27 | long cell values carry the full text in a tool… | `true` | `true` | PASS |
| G28 | short values are not given a redundant tooltip | `true` | `true` | PASS |
| G29 | tooltip text is escaped, not injected | `true` | `true` | PASS |
| G30 | tree rows expose the full label on hover | `true` | `true` | PASS |
| G20 | tree filter reaches nodes that are still colla… | `true` | `true` | PASS |
| G19 | empty result set shows an empty state, not a b… | `true` | `true` | PASS |

**101 passed, 0 failed, 101 total**

## 8. Manual GUI checks

Not automatable headlessly; run these in Chrome over `http://localhost`.

| ID | Step | Expected |
|---|---|---|
| M1 | Open the tool with no file | Drop zone visible, no tabs |
| M2 | Open via `file://` | Amber banner naming the origin restriction and the serve command |
| M3 | Drop `northwind_sim.bak` | Header shows name, size, `BAK` badge |
| M4 | Build object tree | Tree appears, root labelled, Tables (8) |
| M5 | Expand Tables, click `dbo.Order Details` | Right pane lists 5 columns with types |
| M6 | Click its Data node | Grid: 6 rows, `#` column, Discount reads `0`, `0.15`, `0.2` |
| M7 | Click `dbo.Customers` Data | `Ben & Jerry's <Nordic> "AB"` shown as text, no bold rendering |
| M8 | Same grid, Region column | ALFKI `NULL` (grey italic), ANATR `(empty)` |
| M9 | Type `order` in the tree filter with everything collapsed | `dbo.Orders`, `dbo.Order Details`, `CustOrderHist`, `CustOrdersDetail` all revealed |
| M10 | Programmability → Stored Procedures → `dbo.SalesByCategory` | Full source, comment block grey, keywords blue, `'1998'` green |
| M11 | Press Copy on a definition | Button reads `Copied` |
| M12 | Press Download .sql | File saves with the procedure name |
| M13 | STORAGE tab | Page map renders sharp on a Retina display, hover reports offsets |
| M14 | DIAGNOSTICS tab | Candidates table shows `41:0` selected with a match percentage |
| M15 | Resize below 860 px | Tree and detail stack, no horizontal page scroll |
| M16 | Open `dbo.Customers` Data on a narrow window | Only the grid scrolls sideways; the toolbar stays put |
| M17 | Scroll that grid right | `#` column and its header stay locked together at the left |
| M18 | Read the column headers | `CustomerID`, not `CUSTOMERID`; `nchar(5)`, not `NCHAR(5)` |
| M19 | Hover the clipped BENJR Address cell | Tooltip shows the full value |
| M20 | Drag the right edge of the tree pane | Pane widens, long allocation-unit labels become readable |
| M21 | Open `dbo.Orders` Data, drag the edge of the `OrderDate` header | Column narrows, cursor is a resize arrow, neighbours unchanged |
| M22 | Drag that edge far to the left | Column stops at ~44 px rather than collapsing |
| M23 | Double-click the `ShipName` header edge | Column widens to fit its longest value |
| M24 | Resize a column, switch to another table and back | Your widths are still there |
| M25 | Press Reset column widths | Columns return to their measured defaults |
| M26 | Resize while the grid is scrolled right | `#` column stays anchored, no flicker |

## 9. Regression suites

Run all four before shipping a change:

```bash
node test.js     # catalogue layout independence (21 checks × 4 layouts)
node test2.js    # synthetic pipeline + decoy unit (29 checks)
node test3.js    # page-index scale, 1.4 M pages (11 checks)
node test4.js    # resizable grid columns (33 checks)
node stp.js      # this procedure (101 checks)

node run-all.js  # all of the above, one summary
```

Total: 258 assertions.

## 10. Known limitations

* Off-row LOB chunks are marked, not followed — a definition or value pushed
  off-row shows a placeholder.
* Object to allocation-unit mapping is by row shape. Two tables with an
  identical fixed length and column count can collide; the Storage node lists
  every candidate.
* Null-bitmap positions assume no dropped columns. A table that has had
  `ALTER TABLE DROP COLUMN` applied can shift values by one position.
* Nullability is not reported — the `syscolpars.status` bit cannot be located
  reliably, so it is left blank rather than guessed.
* Compressed or encrypted backups yield no readable pages; the Storage tab
  reports the low page density that indicates this.
