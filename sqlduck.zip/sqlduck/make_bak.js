/* ===================================================================
   Builds northwind_sim.bak — an MTF-wrapped SQL Server backup file
   containing real 8 KB pages: the system catalogue (sysschobjs,
   syscolpars, sysobjvalues), a decoy sysidxstats unit, and heaps for
   the Northwind tables.

   The row bytes are produced by the SAME layout rules the reader
   applies, so a decode mismatch is a genuine reader bug rather than a
   fixture artefact. Deliberate edge cases are seeded and listed in
   EDGE_CASES below.
   =================================================================== */
const fs = require('fs');

const PS = 8192;
const VAR = new Set([34, 35, 98, 99, 165, 167, 231, 240, 241]);
const T = { int:56, smallint:52, bit:104, money:60, real:59, datetime:61,
            nchar:239, nvarchar:231, ntext:99, image:34, varchar:167 };

const u16 = s => Buffer.from(s, 'utf16le');
const days1900 = (y,m,d) => (Date.UTC(y, m-1, d) - Date.UTC(1900,0,1)) / 86400000;

/* ---- layout: mirrors layoutFromCols() in sqlduck.html ---- */
function layout(cols){
  let off = 0, bitByte = -1, bitPos = 8, varIdx = 0;
  const out = cols.map((c, i) => {
    const variable = VAR.has(c.xtype) || c.len === -1;
    const o = { ...c, nullBit: i, variable, fixedOff: -1, bitPos: 0, varIndex: -1 };
    if (variable) o.varIndex = varIdx++;
    else if (c.xtype === T.bit) { if (bitPos > 7) { bitByte = off; off += 1; bitPos = 0; } o.fixedOff = bitByte; o.bitPos = bitPos++; }
    else { o.fixedOff = off; off += c.len; }
    return o;
  });
  return { cols: out, fixedLen: off, varCount: varIdx };
}

/* ---- encode one row against a layout ---- */
function buildRow(L, values){
  const fixed = Buffer.alloc(L.fixedLen);
  const vars = new Array(L.varCount).fill(null).map(() => Buffer.alloc(0));
  const nulls = [];
  L.cols.forEach(c => {
    const v = values[c.name];
    if (v === null || v === undefined) { nulls.push(c.nullBit); return; }
    if (c.variable) {
      vars[c.varIndex] = (c.xtype === T.varchar) ? Buffer.from(String(v), 'latin1') : u16(String(v));
      return;
    }
    const o = c.fixedOff;
    switch (c.xtype) {
      case T.int:      fixed.writeInt32LE(v, o); break;
      case T.smallint: fixed.writeInt16LE(v, o); break;
      case T.bit:      if (v) fixed[o] |= (1 << c.bitPos); break;
      case T.real:     fixed.writeFloatLE(v, o); break;
      case T.money: {  let n = BigInt(Math.round(v * 10000)); fixed.writeBigInt64LE(n, o); break; }
      case T.datetime: { const [y,mo,d,tick] = v; fixed.writeUInt32LE(tick||0, o); fixed.writeInt32LE(days1900(y,mo,d), o+4); break; }
      case T.nchar: {  const b = u16(String(v).padEnd(c.len/2, ' ')); b.copy(fixed, o, 0, c.len); break; }
      default: throw new Error('no encoder for xtype ' + c.xtype);
    }
  });
  return rec(fixed, vars, L.cols.length, nulls);
}

/* ---- generic record builder ---- */
function rec(fixed, vars, nCols, nulls){
  const nb = Math.ceil(nCols / 8);
  const head = 4 + fixed.length + 2 + nb + (vars.length ? 2 + 2*vars.length : 0);
  const r = Buffer.alloc(head + vars.reduce((a,v) => a + v.length, 0));
  r[0] = 0x10 | (vars.length ? 0x20 : 0);
  r.writeUInt16LE(4 + fixed.length, 2);
  fixed.copy(r, 4);
  let p = 4 + fixed.length;
  r.writeUInt16LE(nCols, p); p += 2;
  (nulls||[]).forEach(i => { r[p + (i>>3)] |= (1 << (i&7)); });
  p += nb;
  if (vars.length) {
    r.writeUInt16LE(vars.length, p); p += 2;
    let end = head, offAt = p; p += 2*vars.length;
    vars.forEach((v,i) => { end += v.length; r.writeUInt16LE(end, offAt + i*2); });
    vars.forEach(v => { v.copy(r, p); p += v.length; });
  }
  return r;
}

const pages = [];
function makePages(records, obj, ix){
  let i = 0;
  while (i < records.length) {
    const page = Buffer.alloc(PS);
    page[0] = 1; page[1] = 1; page[3] = 0;
    page.writeUInt16LE(ix, 6);
    page.writeUInt32LE(obj, 24);
    page.writeUInt32LE(pages.length + 9, 32);
    page.writeUInt16LE(1, 36);
    let cur = 96, n = 0;
    while (i < records.length) {
      const r = records[i];
      if (cur + r.length > PS - 2*(n+1) - 32) break;
      r.copy(page, cur); page.writeUInt16LE(cur, PS - 2 - n*2);
      cur += r.length; n++; i++;
    }
    page.writeUInt16LE(n, 22);
    page.writeUInt16LE(cur, 30);
    page.writeUInt16LE(PS - 2*n - cur, 28);
    pages.push(page);
  }
}

/* =================== the Northwind schema =================== */
const c = (name, xtype, len, prec, scale) => ({ name, xtype, len, prec: prec||0, scale: scale||0 });
const nv = n => 2*n;

const TABLES = {
  'Categories': { id: 1093578934, cols: [
    c('CategoryID', T.int, 4), c('CategoryName', T.nvarchar, nv(15)),
    c('Description', T.ntext, 16), c('Picture', T.image, 16) ]},
  'Customers': { id: 1109578991, cols: [
    c('CustomerID', T.nchar, nv(5)), c('CompanyName', T.nvarchar, nv(40)),
    c('ContactName', T.nvarchar, nv(30)), c('ContactTitle', T.nvarchar, nv(30)),
    c('Address', T.nvarchar, nv(60)), c('City', T.nvarchar, nv(15)),
    c('Region', T.nvarchar, nv(15)), c('PostalCode', T.nvarchar, nv(10)),
    c('Country', T.nvarchar, nv(15)), c('Phone', T.nvarchar, nv(24)),
    c('Fax', T.nvarchar, nv(24)) ]},
  'Employees': { id: 1125579048, cols: [
    c('EmployeeID', T.int, 4), c('LastName', T.nvarchar, nv(20)),
    c('FirstName', T.nvarchar, nv(10)), c('Title', T.nvarchar, nv(30)),
    c('TitleOfCourtesy', T.nvarchar, nv(25)), c('BirthDate', T.datetime, 8),
    c('HireDate', T.datetime, 8), c('City', T.nvarchar, nv(15)),
    c('Country', T.nvarchar, nv(15)), c('HomePhone', T.nvarchar, nv(24)),
    c('ReportsTo', T.int, 4) ]},
  'Products': { id: 1141579105, cols: [
    c('ProductID', T.int, 4), c('ProductName', T.nvarchar, nv(40)),
    c('SupplierID', T.int, 4), c('CategoryID', T.int, 4),
    c('QuantityPerUnit', T.nvarchar, nv(20)), c('UnitPrice', T.money, 8),
    c('UnitsInStock', T.smallint, 2), c('UnitsOnOrder', T.smallint, 2),
    c('ReorderLevel', T.smallint, 2), c('Discontinued', T.bit, 1) ]},
  'Orders': { id: 1157579162, cols: [
    c('OrderID', T.int, 4), c('CustomerID', T.nchar, nv(5)),
    c('EmployeeID', T.int, 4), c('OrderDate', T.datetime, 8),
    c('RequiredDate', T.datetime, 8), c('ShippedDate', T.datetime, 8),
    c('ShipVia', T.int, 4), c('Freight', T.money, 8),
    c('ShipName', T.nvarchar, nv(40)), c('ShipCity', T.nvarchar, nv(15)),
    c('ShipCountry', T.nvarchar, nv(15)) ]},
  'Order Details': { id: 1173579219, cols: [
    c('OrderID', T.int, 4), c('ProductID', T.int, 4),
    c('UnitPrice', T.money, 8), c('Quantity', T.smallint, 2),
    c('Discount', T.real, 4) ]},
  'Shippers': { id: 1189579276, cols: [
    c('ShipperID', T.int, 4), c('CompanyName', T.nvarchar, nv(40)),
    c('Phone', T.nvarchar, nv(24)) ]},
  'Suppliers': { id: 1205579333, cols: [
    c('SupplierID', T.int, 4), c('CompanyName', T.nvarchar, nv(40)),
    c('ContactName', T.nvarchar, nv(30)), c('City', T.nvarchar, nv(15)),
    c('Country', T.nvarchar, nv(15)), c('Phone', T.nvarchar, nv(24)) ]},
};

/* deliberately seeded edge cases, asserted by the STP */
const EDGE_CASES = {
  html:     "Ben & Jerry's <Nordic> \"AB\"",
  emptyStr: '',
  ctrl:     'Ana\u0007Trujillo',
  longAmp:  'XXX' + '&'.repeat(100),
};

const DATA = {
  'Categories': [
    { CategoryID:1, CategoryName:'Beverages',      Description:null, Picture:null },
    { CategoryID:2, CategoryName:'Condiments',     Description:null, Picture:null },
    { CategoryID:3, CategoryName:'Confections',    Description:null, Picture:null },
    { CategoryID:4, CategoryName:'Dairy Products', Description:null, Picture:null },
  ],
  'Customers': [
    { CustomerID:'ALFKI', CompanyName:'Alfreds Futterkiste', ContactName:'Maria Anders', ContactTitle:'Sales Representative',
      Address:'Obere Str. 57', City:'Berlin', Region:null, PostalCode:'12209', Country:'Germany',
      Phone:'030-0074321', Fax:'030-0076545' },
    { CustomerID:'ANATR', CompanyName:'Ana Trujillo Emparedados', ContactName:EDGE_CASES.ctrl, ContactTitle:'Owner',
      Address:'Avda. de la Constitucion 2222', City:'Mexico D.F.', Region:EDGE_CASES.emptyStr, PostalCode:'05021',
      Country:'Mexico', Phone:'(5) 555-4729', Fax:null },
    { CustomerID:'BENJR', CompanyName:EDGE_CASES.html, ContactName:'Chris <b>Bold</b>', ContactTitle:'Owner',
      Address:EDGE_CASES.longAmp, City:'Vermont', Region:'VT', PostalCode:'05452', Country:'USA',
      Phone:'(802) 555-0100', Fax:null },
    { CustomerID:'BLONP', CompanyName:'Blondel pere et fils', ContactName:'Frederique Citeaux', ContactTitle:'Marketing Manager',
      Address:'24, place Kleber', City:'Strasbourg', Region:null, PostalCode:'67000', Country:'France',
      Phone:'88.60.15.31', Fax:'88.60.15.32' },
    { CustomerID:'HILAA', CompanyName:'HILARION-Abastos', ContactName:'Carlos Hernandez', ContactTitle:'Sales Representative',
      Address:'Carrera 22 con Ave. Carlos Soublette', City:'San Cristobal', Region:'Tachira', PostalCode:'5022',
      Country:'Venezuela', Phone:'(5) 555-1340', Fax:'(5) 555-1948' },
  ],
  'Employees': [
    { EmployeeID:1, LastName:'Davolio', FirstName:'Nancy', Title:'Sales Representative', TitleOfCourtesy:'Ms.',
      BirthDate:[1968,12,8,0], HireDate:[1992,5,1,0], City:'Seattle', Country:'USA', HomePhone:'(206) 555-9857', ReportsTo:2 },
    { EmployeeID:2, LastName:'Fuller', FirstName:'Andrew', Title:'Vice President, Sales', TitleOfCourtesy:'Dr.',
      BirthDate:[1952,2,19,0], HireDate:[1992,8,14,0], City:'Tacoma', Country:'USA', HomePhone:'(206) 555-9482', ReportsTo:null },
    { EmployeeID:3, LastName:'Leverling', FirstName:'Janet', Title:'Sales Representative', TitleOfCourtesy:'Ms.',
      BirthDate:[1963,8,30,0], HireDate:[1992,4,1,0], City:'Kirkland', Country:'USA', HomePhone:'(206) 555-3412', ReportsTo:2 },
  ],
  'Products': [
    { ProductID:1,  ProductName:'Chai',                 SupplierID:1, CategoryID:1, QuantityPerUnit:'10 boxes x 20 bags', UnitPrice:18.00, UnitsInStock:39, UnitsOnOrder:0,  ReorderLevel:10, Discontinued:0 },
    { ProductID:2,  ProductName:'Chang',                SupplierID:1, CategoryID:1, QuantityPerUnit:'24 - 12 oz bottles', UnitPrice:19.00, UnitsInStock:17, UnitsOnOrder:40, ReorderLevel:25, Discontinued:0 },
    { ProductID:5,  ProductName:'Chef Antons Gumbo Mix',SupplierID:2, CategoryID:2, QuantityPerUnit:'36 boxes',           UnitPrice:21.35, UnitsInStock:0,  UnitsOnOrder:0,  ReorderLevel:0,  Discontinued:1 },
    { ProductID:38, ProductName:'Cote de Blaye',        SupplierID:18,CategoryID:1, QuantityPerUnit:'12 - 75 cl bottles', UnitPrice:263.50,UnitsInStock:17, UnitsOnOrder:0,  ReorderLevel:15, Discontinued:0 },
    { ProductID:43, ProductName:'Ipoh Coffee',          SupplierID:20,CategoryID:1, QuantityPerUnit:'16 - 500 g tins',    UnitPrice:46.00, UnitsInStock:17, UnitsOnOrder:10, ReorderLevel:25, Discontinued:0 },
  ],
  'Orders': [
    { OrderID:10248, CustomerID:'ALFKI', EmployeeID:5, OrderDate:[1996,7,4,0], RequiredDate:[1996,8,1,0], ShippedDate:[1996,7,16,0], ShipVia:3, Freight:32.38, ShipName:'Vins et alcools Chevalier', ShipCity:'Reims', ShipCountry:'France' },
    { OrderID:10249, CustomerID:'ANATR', EmployeeID:6, OrderDate:[1996,7,5,0], RequiredDate:[1996,8,16,0],ShippedDate:[1996,7,10,0], ShipName:'Toms Spezialitaten', ShipVia:1, Freight:11.61, ShipCity:'Munster', ShipCountry:'Germany' },
    { OrderID:10250, CustomerID:'BENJR', EmployeeID:4, OrderDate:[1996,7,8,0], RequiredDate:[1996,8,5,0], ShippedDate:null,          ShipVia:2, Freight:65.83, ShipName:'Hanari Carnes', ShipCity:'Rio de Janeiro', ShipCountry:'Brazil' },
    { OrderID:10251, CustomerID:'BLONP', EmployeeID:3, OrderDate:[1996,7,8,0], RequiredDate:[1996,8,5,0], ShippedDate:[1996,7,15,0], ShipVia:1, Freight:41.34, ShipName:'Victuailles en stock', ShipCity:'Lyon', ShipCountry:'France' },
  ],
  'Order Details': [
    { OrderID:10248, ProductID:1,  UnitPrice:14.00, Quantity:12, Discount:0 },
    { OrderID:10248, ProductID:2,  UnitPrice:9.80,  Quantity:10, Discount:0 },
    { OrderID:10249, ProductID:5,  UnitPrice:42.40, Quantity:40, Discount:0 },
    { OrderID:10250, ProductID:38, UnitPrice:263.50,Quantity:15, Discount:0.15 },
    { OrderID:10250, ProductID:43, UnitPrice:16.80, Quantity:35, Discount:0.20 },
    { OrderID:10251, ProductID:1,  UnitPrice:18.00, Quantity:6,  Discount:0.05 },
  ],
  'Shippers': [
    { ShipperID:1, CompanyName:'Speedy Express',   Phone:'(503) 555-9831' },
    { ShipperID:2, CompanyName:'United Package',   Phone:'(503) 555-3199' },
    { ShipperID:3, CompanyName:'Federal Shipping', Phone:'(503) 555-9931' },
  ],
  'Suppliers': [
    { SupplierID:1, CompanyName:'Exotic Liquids', ContactName:'Charlotte Cooper', City:'London', Country:'UK', Phone:'(171) 555-2222' },
    { SupplierID:2, CompanyName:'New Orleans Cajun Delights', ContactName:'Shelley Burke', City:'New Orleans', Country:'USA', Phone:'(100) 555-4822' },
  ],
};

/* ---- views and procedures ---- */
const MODULES = {
  'Alphabetical list of products': { id: 1301579675, type:'V ', text:
`CREATE VIEW [Alphabetical list of products] AS
SELECT Products.*, Categories.CategoryName
FROM Categories INNER JOIN Products ON Categories.CategoryID = Products.CategoryID
WHERE Products.Discontinued = 0` },
  'Current Product List': { id: 1317579732, type:'V ', text:
`CREATE VIEW [Current Product List] AS
SELECT ProductID, ProductName
FROM Products
WHERE Discontinued = 0` },
  'CustOrderHist': { id: 1333579789, type:'P ', text:
`CREATE PROCEDURE CustOrderHist @CustomerID nchar(5)
AS
SELECT ProductName, Total = SUM(Quantity)
FROM Products P, [Order Details] OD, Orders O, Customers C
WHERE C.CustomerID = @CustomerID
  AND C.CustomerID = O.CustomerID
  AND O.OrderID = OD.OrderID
  AND OD.ProductID = P.ProductID
GROUP BY ProductName` },
  'CustOrdersDetail': { id: 1349579846, type:'P ', text:
`CREATE PROCEDURE CustOrdersDetail @OrderID int
AS
SELECT ProductName,
    UnitPrice = ROUND(Od.UnitPrice, 2),
    Quantity,
    Discount = CONVERT(int, Discount * 100),
    ExtendedPrice = ROUND(CONVERT(money, Od.UnitPrice * Quantity * (1 - Discount) / 100) * 100, 2)
FROM Products P, [Order Details] Od
WHERE Od.ProductID = P.ProductID and Od.OrderID = @OrderID` },
  'Ten Most Expensive Products': { id: 1365579903, type:'P ', text:
`CREATE PROCEDURE [Ten Most Expensive Products] AS
SET ROWCOUNT 10
SELECT Products.ProductName AS TenMostExpensiveProducts, Products.UnitPrice
FROM Products
ORDER BY Products.UnitPrice DESC` },
  /* long enough to be split into more than one sysobjvalues chunk */
  'SalesByCategory': { id: 1381579960, type:'P ', text:
`/* ${'='.repeat(70)}
   SalesByCategory
   ${'-'.repeat(70)}
${Array.from({length:60},(_,i)=>'   note line '+(i+1)+' : padding so the definition spans several 4000-character chunks').join('\n')}
   ${'='.repeat(70)} */
CREATE PROCEDURE SalesByCategory
    @CategoryName nvarchar(15), @OrdYear nvarchar(4) = '1998'
AS
IF @OrdYear != '1996' AND @OrdYear != '1997' AND @OrdYear != '1998'
BEGIN
    SELECT @OrdYear = '1998'
END

SELECT ProductName,
    TotalPurchase = ROUND(SUM(CONVERT(decimal(14,2), OD.Quantity * (1 - OD.Discount) * OD.UnitPrice)), 0)
FROM [Order Details] OD, Orders O, Products P, Categories C
WHERE OD.OrderID = O.OrderID
    AND OD.ProductID = P.ProductID
    AND P.CategoryID = C.CategoryID
    AND C.CategoryName = @CategoryName
    AND SUBSTRING(CONVERT(nvarchar(22), O.OrderDate, 111), 1, 4) = @OrdYear
GROUP BY ProductName
ORDER BY ProductName` },
};

/* =================== catalogue pages =================== */
const SYS_OBJS = [
  { id:34, name:'sysschobjs',    type:'S ', nsid:4, pid:0 },
  { id:41, name:'syscolpars',    type:'S ', nsid:4, pid:0 },
  { id:5,  name:'sysrowsets',    type:'S ', nsid:4, pid:0 },
  { id:7,  name:'sysallocunits', type:'S ', nsid:4, pid:0 },
  { id:54, name:'sysidxstats',   type:'S ', nsid:4, pid:0 },
  { id:60, name:'sysobjvalues',  type:'S ', nsid:4, pid:0 },
];
const objRows = [...SYS_OBJS];
Object.entries(TABLES).forEach(([name, t]) => objRows.push({ id:t.id, name, type:'U ', nsid:1, pid:0 }));
Object.entries(MODULES).forEach(([name, m]) => objRows.push({ id:m.id, name, type:m.type, nsid:1, pid:0 }));
/* constraints hanging off tables, so the Keys / Constraints nodes populate */
objRows.push({ id:1400000001, name:'PK_Customers',        type:'PK', nsid:1, pid:TABLES['Customers'].id });
objRows.push({ id:1400000002, name:'PK_Orders',           type:'PK', nsid:1, pid:TABLES['Orders'].id });
objRows.push({ id:1400000003, name:'FK_Orders_Customers', type:'F ', nsid:1, pid:TABLES['Orders'].id });
objRows.push({ id:1400000004, name:'DF_Products_Discontinued', type:'D ', nsid:1, pid:TABLES['Products'].id });

/* sysschobjs on-disk layout: fixed 44, type char(2) @17, nsid @4, pid @19,
   created @23, modified @31 — deliberately not the textbook offsets */
makePages(objRows.map(o => {
  const f = Buffer.alloc(44);
  f.writeInt32LE(o.id, 0); f.writeInt32LE(o.nsid, 4);
  f.write(o.type, 17, 'latin1'); f.writeInt32LE(o.pid, 19);
  f.writeUInt32LE(0, 23); f.writeInt32LE(days1900(1998,3,12), 27);
  f.writeUInt32LE(0, 31); f.writeInt32LE(days1900(2024,11,5), 35);
  return rec(f, [u16(o.name)], 11);
}), 34, 0);

/* syscolpars: real SQL Server layout */
const colRows = [];
Object.values(TABLES).forEach(t => t.cols.forEach((col, i) => {
  const f = Buffer.alloc(41);
  f.writeInt32LE(t.id, 0); f.writeInt16LE(0, 4); f.writeInt32LE(i+1, 6);
  f[10] = col.xtype; f.writeInt16LE(col.len, 15); f[17] = col.prec; f[18] = col.scale;
  colRows.push(rec(f, [u16(col.name)], 16));
}));
/* the two views also own columns */
[['Alphabetical list of products',['ProductID','ProductName','CategoryName']],
 ['Current Product List',['ProductID','ProductName']]].forEach(([vn, names]) => {
  names.forEach((n, i) => {
    const f = Buffer.alloc(41);
    f.writeInt32LE(MODULES[vn].id, 0); f.writeInt16LE(0, 4); f.writeInt32LE(i+1, 6);
    f[10] = T.nvarchar; f.writeInt16LE(nv(40), 15);
    colRows.push(rec(f, [u16(n)], 16));
  });
});
makePages(colRows, 41, 0);

/* sysobjvalues: definitions split into 4000-character chunks */
const ovRows = [];
Object.values(MODULES).forEach(m => {
  const CH = 4000;
  for (let i = 0, n = 1; i < m.text.length; i += CH, n++) {
    const f = Buffer.alloc(13);
    f[0] = 1; f.writeInt32LE(m.id, 1); f.writeInt32LE(0, 5); f.writeInt32LE(n, 9);
    ovRows.push(rec(f, [Buffer.alloc(0), u16(m.text.slice(i, i+CH))], 6));
  }
});
makePages(ovRows, 60, 0);

/* decoy: sysidxstats also has object ids at offset 0 plus a name column */
const decoy = [];
const allIds = objRows.map(o => o.id);
for (let i = 0; i < 30; i++) {
  const f = Buffer.alloc(39);
  f.writeInt32LE(allIds[i % allIds.length], 0);
  f.writeInt32LE((i % 3) + 1, 4);
  f[17] = (i % 3) + 1;
  decoy.push(rec(f, [u16('IX_Northwind_' + i)], 11));
}
makePages(decoy, 54, 0);

/* table heaps */
const LAYOUTS = {};
Object.entries(TABLES).forEach(([name, t]) => {
  const L = layout(t.cols);
  LAYOUTS[name] = L;
  makePages(DATA[name].map(r => buildRow(L, r)), t.id, 0);
});

/* =================== MTF wrapper =================== */
function mtfBlock(sig, strings, size){
  const b = Buffer.alloc(1024);
  b.write(sig, 0, 'latin1');
  b.writeUInt32LE(sig === 'SSET' ? 0x00000004 : 0, 4);
  b.writeUInt16LE(52, 8);
  b[10] = 14; b[11] = 0;
  b.writeBigUInt64LE(BigInt(size || 0), 12);
  let p = 64;
  (strings||[]).forEach(s => { const u = u16(s); if (p + u.length + 4 < 1024) { u.copy(b, p); p += u.length + 4; } });
  return b;
}
const dataBytes = pages.length * PS;
const header = Buffer.concat([
  mtfBlock('TAPE', ['SQLDUCK test media', 'Northwind'], 0),
  mtfBlock('SSET', ['Northwind', 'Northwind-Full Database Backup', 'SQLDUCK-FIXTURE'], dataBytes),
  mtfBlock('VOLB', ['Northwind'], 0),
  mtfBlock('DIRB', ['Northwind'], 0),
  mtfBlock('FILE', ['Northwind_Data', 'C:\\MSSQL\\DATA\\Northwind.mdf',
                    'Northwind_Log',  'C:\\MSSQL\\DATA\\Northwind_log.ldf'], dataBytes),
  mtfBlock('MSDA', ['Northwind_Data'], dataBytes),
]);
const footer = Buffer.concat([ mtfBlock('ESET', ['Northwind'], dataBytes), mtfBlock('EOTM', [], 0) ]);
const out = Buffer.concat([header, ...pages, footer]);

const path = './northwind_sim.bak';
fs.writeFileSync(path, out);
fs.writeFileSync('./fixture.json', JSON.stringify({
  path, size: out.length, pages: pages.length, dataStart: header.length,
  tables: Object.fromEntries(Object.entries(TABLES).map(([n,t]) => [n, {
    id: t.id, cols: t.cols.map(x => x.name), fixedLen: LAYOUTS[n].fixedLen,
    varCount: LAYOUTS[n].varCount, rows: DATA[n].length }])),
  modules: Object.fromEntries(Object.entries(MODULES).map(([n,m]) => [n, { id:m.id, type:m.type, len:m.text.length, text:m.text }])),
  edge: EDGE_CASES,
}, null, 1));

console.log('wrote ' + path);
console.log('  ' + (out.length/1024).toFixed(1) + ' KB, ' + pages.length + ' pages, MTF header ' + header.length + ' bytes');
Object.entries(TABLES).forEach(([n,t]) =>
  console.log('  ' + n.padEnd(15) + ' fixed=' + String(LAYOUTS[n].fixedLen).padStart(3) +
              ' cols=' + String(t.cols.length).padStart(2) + ' var=' + LAYOUTS[n].varCount +
              ' rows=' + DATA[n].length));
