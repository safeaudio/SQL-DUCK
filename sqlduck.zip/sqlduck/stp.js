/* =====================================================================
   SQLDUCK Self-Test Procedure
   Drives the real application code (extracted from sqlduck.html) against
   northwind_sim.bak, exercising the full path a user takes:
   detect -> scan -> recover catalogue -> read columns -> browse rows ->
   read procedure source -> render.
   Usage:  node stp.js            (human readable)
           node stp.js --md       (markdown results table)
   ===================================================================== */
const fs = require('fs'), vm = require('vm');

const HTML = process.env.SQLDUCK || './sqlduck.html';
const BAK  = process.env.BAK || './northwind_sim.bak';
const FIX  = JSON.parse(fs.readFileSync('./fixture.json', 'utf8'));
const MD   = process.argv.includes('--md');

/* ---------------- headless DOM ---------------- */
const nodes = {};
function el(id){
  if (nodes[id]) return nodes[id];
  const o = { id, hidden:true, innerHTML:'', textContent:'', value:'', checked:false,
    options:{length:1}, selectedOptions:[{text:''}], style:{}, dataset:{},
    classList:{ toggle(){}, add(){}, remove(){}, contains(){return false;} },
    add(){}, appendChild(){}, removeChild(){}, remove(){}, click(){}, focus(){},
    querySelector(){ return el('_x'); }, querySelectorAll(){ return []; },
    getContext(){ return { fillRect(){}, fillStyle:'' }; }, getBoundingClientRect(){ return {left:0,width:900}; },
    clientWidth:900, width:900, height:48 };
  nodes[id] = o; return o;
}
el('scanLimit').value = '0';          // entire file, the shipped default
el('strict').checked  = true;         // auto-set for .bak
el('rGhost').checked  = true;
const ctx = {
  console, navigator:{ clipboard:{ writeText: async()=>{} } },
  location:{ protocol:'http:' }, confirm:()=>true, alert(){},
  document:{
    querySelector(sel){ return el(sel.replace('#','')); },
    querySelectorAll(){ return []; },
    addEventListener(){}, createElement(){ return el('_new'); },
    body:{ appendChild(){}, removeChild(){} }
  },
  window:{ addEventListener(){}, open:()=>null },
  setTimeout, clearTimeout, Blob:class{ constructor(p){ this.parts=p; } },
  URL:{ createObjectURL(){ return 'blob:x'; }, revokeObjectURL(){} },
  FileReader:class{ readAsText(){ this.onload && this.onload(); } },
  Option:class{ constructor(t,v){ this.text=t; this.value=v; } },
};
ctx.globalThis = ctx;
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(HTML,'utf8').match(/<script>([\s\S]*?)<\/script>/)[1], ctx, {filename:'sqlduck.js'});

/* ---------------- feed the .bak in as a File ---------------- */
const buf = fs.readFileSync(BAK);
ctx.__BUF = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.length);
vm.runInContext(`
  S.file = { name:'northwind_sim.bak', size:${buf.length},
             slice:(a,b)=>({ arrayBuffer: async()=>__BUF.slice(a,b) }) };`, ctx);

/* ---------------- results ---------------- */
const R = [];
let section = '';
const sec = s => { section = s; if (!MD) console.log('\n' + s); };
function check(id, what, expected, actualFn){
  let actual, ok;
  try { actual = actualFn(); ok = (actual === expected) || (expected === '<non-empty>' && !!actual); }
  catch(e){ actual = 'ERROR: ' + e.message; ok = false; }
  R.push({ id, section, what, expected:String(expected), actual:String(actual), ok });
  if (!MD) console.log('  ' + (ok?'PASS':'FAIL') + '  ' + id + '  ' + what +
    (ok ? '' : '\n          expected: ' + expected + '\n          actual:   ' + actual));
  return ok;
}
const run = s => vm.runInContext(s, ctx);

(async () => {
  /* ============ A. file handling ============ */
  sec('A — FILE HANDLING');
  const kind = await run('detectKind()');
  check('A1','MTF backup recognised from the TAPE signature','bak',()=>kind);
  run(`S.kind='${kind}'`);

  await run('scanMtf()');
  const mtf = run('$("#mtfBody").innerHTML');
  check('A2','tape blocks listed (TAPE/SSET/FILE)', true, ()=> /TAPE/.test(mtf) && /SSET/.test(mtf) && /FILE/.test(mtf));
  check('A3','MSDA data stream identified', true, ()=> /MSDA/.test(mtf));
  check('A4','backup set names the database', true, ()=> /Northwind/.test(mtf));

  /* ============ B. scan ============ */
  sec('B — PAGE SCAN');
  await run('scan()');
  check('B1','every 8 KB page inside the MTF stream found', FIX.pages, ()=> run('S.scan.pages.n'));
  check('B2','all pages classified as data pages', FIX.pages, ()=> run('S.scan.byType[1]||0'));
  check('B3','scan covered the whole file', false, ()=> run('S.scan.partial'));
  check('B4','page index did not overflow', false, ()=> run('S.scan.capped'));

  /* ============ C. catalogue ============ */
  sec('C — OBJECT CATALOGUE');
  check('C1','schema recovery reports success', true, ()=> run('SCH.ok'));
  check('C2','user tables recovered', 8, ()=> run("SCH.objs.filter(o=>o.type==='U ').length"));
  check('C3','views recovered', 2, ()=> run("SCH.objs.filter(o=>o.type==='V ').length"));
  check('C4','stored procedures recovered', 4, ()=> run("SCH.objs.filter(o=>o.type==='P ').length"));
  check('C5','table name containing a space is intact', true,
        ()=> run("SCH.objs.some(o=>o.name==='Order Details')"));
  check('C6','dbo schema resolved from schema_id', 'dbo.Customers',
        ()=> run("(function(){const o=SCH.objs.find(x=>x.name==='Customers');return schemaOf(o)+'.'+o.name;})()"));
  check('C7','foreign key linked to its parent table', 'Orders',
        ()=> run("(function(){const f=SCH.objs.find(o=>o.name==='FK_Orders_Customers');return SCH.byId.get(f.pid).name;})()"));
  check('C8','decoy sysidxstats unit rejected', true,
        ()=> run("String(SCH.diag.colparsAU)!=='54:0'"));
  check('C9','column set verified against on-disk row shapes', true,
        ()=> run('SCH.diag.colMatch') >= 0.6);

  /* ============ D. columns ============ */
  sec('D — COLUMN RECOVERY');
  const colsOf = t => run(`(SCH.colsById.get(${FIX.tables[t].id})||[]).map(c=>c.name).join(',')`);
  const typeOf = (t,n) => run(`(function(){const c=(SCH.colsById.get(${FIX.tables[t].id})||[]).find(x=>x.name===${JSON.stringify(n)});return c?typeName(c):'(missing)';})()`);
  Object.keys(FIX.tables).forEach((t,i) =>
    check('D'+(i+1), 'columns of ' + t, FIX.tables[t].cols.join(','), ()=> colsOf(t)));
  check('D9','nchar(5) width reported in characters','nchar(5)',()=>typeOf('Customers','CustomerID'));
  check('D10','nvarchar(40) width reported in characters','nvarchar(40)',()=>typeOf('Customers','CompanyName'));
  check('D11','money type identified','money',()=>typeOf('Orders','Freight'));
  check('D12','real type identified','real',()=>typeOf('Order Details','Discount'));
  check('D13','bit type identified','bit',()=>typeOf('Products','Discontinued'));
  check('D14','ntext LOB type identified','ntext',()=>typeOf('Categories','Description'));
  check('D15','smallint type identified','smallint',()=>typeOf('Products','UnitsInStock'));

  /* ============ E. row values ============ */
  sec('E — TABLE CONTENT (CLEAR VALUE DISPLAY)');
  async function rows(t){
    return await run(`(async function(){
      const id=${FIX.tables[t].id}, L=columnLayout(id), au=matchAllocUnits(id)[0];
      if(!au) return null;
      const sel=pxSelect(S.scan.pages,pxLeafOf(au),50);
      const out=[];
      for(const p of sel.rows){
        const b=await readRange(p.off,PAGE_SIZE), h=parseHeader(b,0);
        for(const r of pageRecords(b,0,h)) if(!r.ghost&&!r.error) out.push(decodeRow(r,L));
      }
      return {cols:L.cols.map(c=>c.name), rows:out};
    })()`);
  }
  const prod = await rows('Products');
  const ord  = await rows('Orders');
  const od   = await rows('Order Details');
  const cust = await rows('Customers');
  const emp  = await rows('Employees');
  const cell = (d,r,c) => d.rows[r][d.cols.indexOf(c)];

  check('E1','Products row count', 5, ()=> prod.rows.length);
  check('E2','int value',            1, ()=> cell(prod,0,'ProductID'));
  check('E3','nvarchar value',  'Chai', ()=> cell(prod,0,'ProductName'));
  check('E4','money value',  '18.0000', ()=> cell(prod,0,'UnitPrice'));
  check('E5','money value with cents','21.3500',()=> cell(prod,2,'UnitPrice'));
  check('E6','large money value','263.5000',()=> cell(prod,3,'UnitPrice'));
  check('E7','smallint value',     39, ()=> cell(prod,0,'UnitsInStock'));
  check('E8','bit value false',     0, ()=> cell(prod,0,'Discontinued'));
  check('E9','bit value true',      1, ()=> cell(prod,2,'Discontinued'));
  check('E10','datetime value','1996-07-04 00:00:00.000',()=> cell(ord,0,'OrderDate'));
  check('E11','NULL datetime reported as null', null, ()=> cell(ord,2,'ShippedDate'));
  check('E12','nchar padded value trimmed','ALFKI',()=> String(cell(ord,0,'CustomerID')).trim());
  check('E13','real value shown without float noise','0.15',()=> String(cell(od,3,'Discount')));
  check('E14','real value 0.2 shown cleanly','0.2',()=> String(cell(od,4,'Discount')));
  check('E15','real zero',          '0', ()=> String(cell(od,0,'Discount')));
  check('E16','NULL int reported as null', null, ()=> cell(emp,1,'ReportsTo'));
  check('E17','NULL nvarchar reported as null', null, ()=> cell(cust,0,'Region'));
  check('E18','empty string is NOT reported as null', '', ()=> cell(cust,1,'Region'));
  const catRows = await rows('Categories');
  check('E19','NULL LOB (ntext) column reported as null', null, ()=> cell(catRows,0,'Description'));
  check('E20','row with a space in the table name reads', 6, ()=> od.rows.length);
  check('E21','Employees datetime','1968-12-08 00:00:00.000',()=> cell(emp,0,'BirthDate'));

  /* ============ F. stored procedures ============ */
  sec('F — STORED PROCEDURE SOURCE');
  const modCount = run('SCH.modules.size');
  check('F1','definitions recovered for every module', 6, ()=> modCount);
  Object.entries(FIX.modules).forEach(([name, m], i) =>
    check('F'+(i+2), 'source of ' + name + ' byte-identical', true,
          ()=> run(`SCH.modules.get(${m.id})`) === m.text));
  const long = FIX.modules['SalesByCategory'];
  check('F8','multi-chunk definition reassembled in order', true,
        ()=> long.len > 4000 && run(`SCH.modules.get(${long.id})`) === long.text);
  const hl = run(`highlightSql(SCH.modules.get(${FIX.modules['CustOrderHist'].id}))`);
  check('F9','keywords highlighted', true, ()=> /<span class="sqk">CREATE<\/span>/.test(hl));
  check('F10','bracketed identifiers highlighted', true,
        ()=> /<span class="sqi">\[Order Details\]<\/span>/.test(hl));
  const hlC = run(`highlightSql(SCH.modules.get(${FIX.modules['SalesByCategory'].id}))`);
  check('F11','block comment highlighted', true, ()=> /<span class="sqc">\/\*/.test(hlC));
  check('F12','string literal highlighted', true, ()=> /<span class="sqs">'1998'<\/span>/.test(hlC));

  /* ============ G. rendering / GUI ============ */
  sec('G — RENDERING AND GUI');
  await run(`browseAllocUnit(matchAllocUnits(${FIX.tables['Customers'].id})[0], SCH.byId.get(${FIX.tables['Customers'].id}))`);
  const grid = run('$("#detail").innerHTML');
  check('G1','grid renders the table name', true, ()=> /dbo\.Customers/.test(grid));
  check('G2','HTML metacharacters in data are escaped', true,
        ()=> /Ben &amp; Jerry&#x27;s &lt;Nordic&gt;/.test(grid) || /Ben &amp; Jerry's &lt;Nordic&gt;/.test(grid));
  check('G3','no live markup leaked from data', true, ()=> !/<b>Bold<\/b>/.test(grid));
  check('G4','truncation never splits an HTML entity', true,
        ()=> !/&(amp|lt|gt|quot|#x27)?$/.test(grid) && !/&[a-z]{0,4}<\/td>/.test(grid));
  check('G5','NULL rendered distinctly', true, ()=> /class="nullv">NULL</.test(grid));
  check('G6','empty string distinguishable from NULL', true, ()=> /class="emptyv"/.test(grid));
  check('G7','control characters replaced for display', true, ()=> grid.indexOf('\u0007') < 0);
  check('G8','row numbers shown', true, ()=> /<th[^>]*>#<\/th>/.test(grid));
  check('G9','column type shown under each header', true, ()=> /class="ty">nvarchar\(40\)</.test(grid));

  const det = run(`(showDetail({kind:'object',obj:SCH.byId.get(${FIX.modules['CustOrderHist'].id})}), $("#detail").innerHTML)`);
  check('G10','procedure detail shows a definition block', true, ()=> /class="sql"/.test(det));
  check('G11','copy and download offered', true, ()=> /id="copySrc"/.test(det) && /id="dlSrc"/.test(det));

  const tree = run(`(function(){
     const kids=buildRoot().build();
     const tbl=kids.find(k=>k.label==='Tables');
     const first=tbl.build().find(n=>n.label==='dbo.Order Details');
     const sub=first.build().map(k=>k.label).join('|');
     return JSON.stringify({folders:kids.map(k=>k.label),tables:tbl.count,sub:sub,
       cols:first.build().find(k=>k.label==='Columns').count});
  })()`);
  const tj = JSON.parse(tree);
  check('G12','tree exposes the expected folders', true,
        ()=> tj.folders.includes('Tables') && tj.folders.includes('Views') && tj.folders.includes('Programmability'));
  check('G13','Tables node reports the right count', 8, ()=> tj.tables);
  check('G14','Data node comes first under a table', true, ()=> tj.sub.startsWith('Data|Columns'));
  check('G15','Columns node populated for a table with a space', 5, ()=> tj.cols);
  check('G16','ribbon survives a zero-width canvas', true,
        ()=> { try { run('drawRibbon()'); return true; } catch(e){ return 'threw: '+e.message; } });
  check('G17','storage tab renders', true,
        ()=> { run('renderStorage()'); return /PAGE MAP/.test(run('$("#ovBody").innerHTML')); });
  check('G18','diagnostics renders candidate table', true,
        ()=> { run('renderDiag()'); return /SYSCOLPARS CANDIDATES TRIED/.test(run('$("#diagBody").innerHTML')); });
  /* CSS-level regressions found from a screenshot of the running app.
     No layout engine here, so these assert the rules that produce the layout. */
  const CSS = fs.readFileSync(HTML,'utf8').split('</style>')[0];
  check('G31','grid offers a reset for column widths', true, ()=> /id="resetW"/.test(grid));
  check('G32','resize affordance is explained next to the grid', true, ()=> /drag a column edge to resize/.test(grid));
  check('G33','header cells can host an absolutely positioned grip', true,
        ()=> /(^|[};])\s*th\{[^}]*position:sticky/.test(CSS));
  check('G34','a grip is drawn on the trailing edge of a header', true,
        ()=> /\.colgrip\{[^}]*cursor:col-resize/.test(CSS));
  check('G35','pointer drags are not swallowed by touch scrolling', true,
        ()=> /\.colgrip\{[^}]*touch-action:none/.test(CSS));
  check('G36','resized tables use fixed layout so widths are honoured', true,
        ()=> /table\.rsz\{table-layout:fixed\}/.test(CSS));
  check('G21','explorer column can shrink below its content width', true,
        ()=> /#explorer\{[^}]*minmax\(0,\s*1fr\)/.test(CSS));
  check('G22','detail pane allows shrinking inside the grid track', true,
        ()=> /#detail\{[^}]*min-width:0/.test(CSS));
  check('G23','page cannot scroll horizontally as a whole', true,
        ()=> /body\{overflow-x:hidden\}/.test(CSS));
  check('G24','row-number header is sticky horizontally, like its cells', true,
        ()=> /\.grid th:first-child\{[^}]*position:sticky;left:0/.test(CSS));
  check('G25','data grid headers keep their real identifier casing', true,
        ()=> /\.grid th\{[^}]*text-transform:none/.test(CSS));
  check('G26','column name reaches the grid unaltered', true,
        ()=> /<th>CustomerID<div class="ty">nchar\(5\)<\/div><\/th>/.test(grid));
  check('G27','long cell values carry the full text in a tooltip', true,
        ()=> /<td title="XXX&amp;&amp;/.test(grid));
  check('G28','short values are not given a redundant tooltip', true,
        ()=> /<td>Berlin<\/td>/.test(grid));
  check('G29','tooltip text is escaped, not injected', true,
        ()=> !/title="[^"]*<b>/.test(grid));
  check('G30','tree rows expose the full label on hover', true,
        ()=> /row\.title=n\.label/.test(fs.readFileSync(HTML,'utf8')));
  check('G20','tree filter reaches nodes that are still collapsed', true,
        ()=> /_open/.test(fs.readFileSync(HTML,'utf8')) && /dataset.depth/.test(fs.readFileSync(HTML,'utf8')));
  check('G19','empty result set shows an empty state, not a bare header', true,
        ()=> { run(`browseAllocUnit({obj:999999,ix:0,n:0},null)`); return /No rows/.test(run('$("#detail").innerHTML')); });

  /* ---------------- report ---------------- */
  const pass = R.filter(r=>r.ok).length, fail = R.length - pass;
  if (MD) {
    let cur = '';
    console.log('| ID | Check | Expected | Actual | Result |');
    console.log('|---|---|---|---|---|');
    R.forEach(r => {
      if (r.section !== cur) { cur = r.section; console.log('| **' + cur + '** | | | | |'); }
      const clip = s => { s = String(s).replace(/\|/g,'\\|'); return s.length>46 ? s.slice(0,46)+'…' : s; };
      console.log('| ' + r.id + ' | ' + clip(r.what) + ' | `' + clip(r.expected) + '` | `' + clip(r.actual) + '` | ' + (r.ok?'PASS':'**FAIL**') + ' |');
    });
    console.log('\n**' + pass + ' passed, ' + fail + ' failed, ' + R.length + ' total**');
  } else {
    console.log('\n' + (fail ? 'FAILED ' + fail + ' of ' + R.length : 'ALL ' + pass + ' CHECKS PASSED'));
  }
  process.exit(fail ? 1 : 0);
})();
