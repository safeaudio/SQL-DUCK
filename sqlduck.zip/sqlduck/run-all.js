#!/usr/bin/env node
/* Runs every SQLDUCK regression suite and prints one summary.
   Usage: node run-all.js            */
const { execFileSync } = require('child_process');

const SUITES = [
  { name: 'catalogue layout  fixed=44 type@17', file: 'test.js',  env: { FIXED:'44', TYPEOFF:'17', PIDOFF:'19' } },
  { name: 'catalogue layout  fixed=40 type@13', file: 'test.js',  env: { FIXED:'40', TYPEOFF:'13', PIDOFF:'15' } },
  { name: 'catalogue layout  fixed=56 type@30', file: 'test.js',  env: { FIXED:'56', TYPEOFF:'30', PIDOFF:'32' } },
  { name: 'catalogue layout  fixed=39 type@9',  file: 'test.js',  env: { FIXED:'39', TYPEOFF:'9',  PIDOFF:'11' } },
  { name: 'synthetic pipeline + decoy unit',    file: 'test2.js', env: {} },
  { name: 'page index scale (1.4 M pages)',     file: 'test3.js', env: {} },
  { name: 'resizable grid columns',            file: 'test4.js', env: {} },
  { name: 'STP vs northwind_sim.bak',           file: 'stp.js',   env: {} },
];

let total = 0, failed = 0;
console.log('\nSQLDUCK regression\n' + '='.repeat(58));
for (const s of SUITES) {
  let out = '', ok = true;
  try {
    out = execFileSync('node', [s.file], { env: { ...process.env, ...s.env }, encoding: 'utf8' });
  } catch (e) {
    out = (e.stdout || '') + (e.stderr || ''); ok = false;
  }
  const last = out.trim().split('\n').pop().trim();
  const m = last.match(/ALL (\d+) CHECKS PASSED/) || last.match(/FAILED (\d+) \/ (\d+)/);
  if (m && /ALL/.test(last)) total += +m[1];
  else { ok = false; failed++; }
  console.log('  ' + (ok ? 'PASS' : 'FAIL') + '  ' + s.name.padEnd(38) + last.slice(0, 34));
  if (!ok) console.log(out.split('\n').filter(l => /FAIL|Error/.test(l)).slice(0, 8).map(l => '        ' + l).join('\n'));
}
console.log('='.repeat(58));
console.log(failed ? '  ' + failed + ' SUITE(S) FAILED' : '  ALL SUITES PASSED — ' + total + ' assertions\n');
process.exit(failed ? 1 : 0);
