const fs = require('fs'), vm = require('vm');
const html = fs.readFileSync((process.env.SQLDUCK || './sqlduck.html'), 'utf8');
const js = html.match(/<script>([\s\S]*?)<\/script>/)[1];

const mkEl = () => new Proxy({}, {
  get: (t, k) => {
    if (k === 'classList') return { toggle(){}, add(){}, remove(){}, contains(){return false;} };
    if (k === 'options' || k === 'selectedOptions') return { length: 1, 0: { text: '' } };
    if (k === 'style' || k === 'dataset') return {};
    if (k === 'querySelector') return () => mkEl();
    if (k === 'querySelectorAll') return () => [];
    if (['appendChild','add','focus','click','onclick'].includes(k)) return () => {};
    if (k === 'value') return '268435456';
    if (k === 'checked') return false;
    if (typeof k === 'string' && k.startsWith('on')) return null;
    return mkEl();
  }, set: () => true
});
const ctx = {
  console, navigator: {},
  document: { querySelector: () => mkEl(), querySelectorAll: () => [], addEventListener(){}, createElement: () => mkEl() },
  window: { addEventListener(){}, open: () => null },
  location: { protocol: 'file:' },
  FileReader: class { readAsText(){ this.onload && this.onload(); } },
  alert(){}, confirm: () => true,
  setTimeout, clearTimeout, Blob: class {}, URL: { createObjectURL(){}, revokeObjectURL(){} },
  Date, Math, JSON, Map, Set, Uint8Array, DataView, BigInt, Number, String, Object, Array, RegExp, Promise, Error
};
ctx.globalThis = ctx;
vm.createContext(ctx);
vm.runInContext(js, ctx, { filename: 'sqlduck.js' });

const PS = 8192;
const pages = [];                       // {buf, obj, ix}
const u16 = s => Buffer.from(s, 'utf16le');

/* generic record builder: fixed buffer + list of variable-length buffers */
function rec(fixed, vars, nCols, nulls) {
  const nb = Math.ceil(nCols / 8);
  const head = 4 + fixed.length + 2 + nb + (vars.length ? 2 + 2 * vars.length : 0);
  const total = head + vars.reduce((a, v) => a + v.length, 0);
  const r = Buffer.alloc(total);
  r[0] = 0x10 | (vars.length ? 0x20 : 0);
  r.writeUInt16LE(4 + fixed.length, 2);
  fixed.copy(r, 4);
  let p = 4 + fixed.length;
  r.writeUInt16LE(nCols, p); p += 2;
  (nulls || []).forEach(i => { r[p + (i >> 3)] |= (1 << (i & 7)); });
  p += nb;
  if (vars.length) {
    r.writeUInt16LE(vars.length, p); p += 2;
    let end = head;
    const offAt = p; p += 2 * vars.length;
    vars.forEach((v, i) => { end += v.length; r.writeUInt16LE(end, offAt + i * 2); });
    vars.forEach(v => { v.copy(r, p); p += v.length; });
  }
  return r;
}
function makePage(records, obj, ix) {
  const page = Buffer.alloc(PS);
  page[0] = 1; page[1] = 1;
  page.writeUInt16LE(ix, 6);
  page.writeUInt16LE(records.length, 22);
  page.writeUInt32LE(obj, 24);
  page.writeUInt32LE(pages.length + 1, 32); page.writeUInt16LE(1, 36);
  let cur = 96;
  records.forEach((r, i) => { r.copy(page, cur); page.writeUInt16LE(cur, PS - 2 - i * 2); cur += r.length; });
  page.writeUInt16LE(cur, 30);
  pages.push({ buf: page, obj, ix });
  return page;
}

/* ---- sysschobjs (objid 34) ---- */
const OBJECTS = [
  { id: 34, nsid: 4, type: 'S ', pid: 0, name: 'sysschobjs' },
  { id: 41, nsid: 4, type: 'S ', pid: 0, name: 'syscolpars' },
  { id: 5,  nsid: 4, type: 'S ', pid: 0, name: 'sysrowsets' },
  { id: 7,  nsid: 4, type: 'S ', pid: 0, name: 'sysallocunits' },
  { id: 60, nsid: 4, type: 'S ', pid: 0, name: 'sysobjvalues' },
  { id: 901578250, nsid: 1, type: 'U ', pid: 0, name: 'Customers' },
  { id: 111111111, nsid: 1, type: 'P ', pid: 0, name: 'usp_GetCustomer' },
  { id: 222222222, nsid: 1, type: 'V ', pid: 0, name: 'vwActiveCustomers' },
];
makePage(OBJECTS.map(o => {
  const f = Buffer.alloc(44);
  f.writeInt32LE(o.id, 0); f.writeInt32LE(o.nsid, 4);
  f.write(o.type, 17, 'latin1'); f.writeInt32LE(o.pid, 19);
  f.writeUInt32LE(12345678, 23); f.writeInt32LE(45000, 27);
  f.writeUInt32LE(22222222, 31); f.writeInt32LE(45300, 35);
  return rec(f, [u16(o.name)], 11);
}), 34, 0);

/* ---- syscolpars (objid 41) : Customers ---- */
const COLS = [
  { colid: 1, xtype: 56,  len: 4,  name: 'CustomerID' },
  { colid: 2, xtype: 231, len: 60, name: 'Name' },
  { colid: 3, xtype: 61,  len: 8,  name: 'Created' },
  { colid: 4, xtype: 104, len: 1,  name: 'IsActive' },
  { colid: 5, xtype: 106, len: 9,  name: 'Balance', prec: 18, scale: 2 },
  { colid: 6, xtype: 167, len: 40, name: 'City' },
];
makePage(COLS.map(c => {
  const f = Buffer.alloc(41);
  f.writeInt32LE(901578250, 0);
  f.writeInt16LE(0, 4);            // number
  f.writeInt32LE(c.colid, 6);
  f[10] = c.xtype;
  f.writeInt16LE(c.len, 15);
  f[17] = c.prec || 0; f[18] = c.scale || 0;
  return rec(f, [u16(c.name)], 16);
}).concat([
  (() => { const f = Buffer.alloc(41); f.writeInt32LE(34, 0); f.writeInt16LE(0, 4); f.writeInt32LE(1, 6); f[10] = 56; f.writeInt16LE(4, 15); return rec(f, [u16('id')], 16); })(),
  (() => { const f = Buffer.alloc(41); f.writeInt32LE(41, 0); f.writeInt16LE(0, 4); f.writeInt32LE(1, 6); f[10] = 56; f.writeInt16LE(4, 15); return rec(f, [u16('id')], 16); })(),
]), 41, 0);

/* ---- DECOY: a sysidxstats-shaped unit. Object ids at offset 0, a name
   column, and more rows than syscolpars, so the old "highest score wins"
   selection picked this and column recovery collapsed to nothing. ---- */
const DECOY_IDS = [901578250, 111111111, 222222222, 34, 41, 5, 7, 60];
const decoyRows = [];
for (let i = 0; i < 24; i++) {
  const f = Buffer.alloc(39);
  f.writeInt32LE(DECOY_IDS[i % DECOY_IDS.length], 0);
  f.writeInt32LE((i % 3) + 1, 4);          // indid
  f.writeInt32LE(0, 8);                    // status
  f[17] = (i % 3) + 1;                     // index type: 1..3, never a SQL xtype
  decoyRows.push(rec(f, [u16('IX_decoy_' + i)], 11));
}
makePage(decoyRows, 54, 0);

/* ---- sysobjvalues (objid 60) : chunked procedure + view source ---- */
const PROC = "CREATE PROCEDURE dbo.usp_GetCustomer\n  @CustomerID int\nAS\nBEGIN\n  SET NOCOUNT ON;\n  -- returns one customer\n  SELECT CustomerID, Name, City\n  FROM dbo.Customers\n  WHERE CustomerID = @CustomerID;\nEND";
const VIEW = "CREATE VIEW dbo.vwActiveCustomers AS\nSELECT CustomerID, Name FROM dbo.Customers WHERE IsActive = 1";
const CHUNK = 40;                                  // force multi-row chunking
function ovRows(objid, text) {
  const out = [];
  for (let i = 0, n = 1; i < text.length; i += CHUNK, n++) {
    const f = Buffer.alloc(13);
    f[0] = 1;                                      // valclass
    f.writeInt32LE(objid, 1);
    f.writeInt32LE(0, 5);                          // subobjid
    f.writeInt32LE(n, 9);                          // valnum
    out.push({ n, r: rec(f, [Buffer.alloc(0), u16(text.slice(i, i + CHUNK))], 6) });
  }
  return out;
}
// deliberately shuffled so the chunk ordering logic is exercised
const ovAll = ovRows(111111111, PROC).concat(ovRows(222222222, VIEW));
ovAll.sort(() => 0.5 - ((ovAll.length % 7) / 7) - 0.2);
makePage(ovAll.map(x => x.r).reverse(), 60, 0);

/* ---- the Customers heap itself ---- */
const ROWS = [
  { id: 1, name: 'Acme Ltd',   dt: [12345678, 45000], act: 1, bal: '12345',   city: 'Jerusalem' },
  { id: 2, name: 'חברת בדיקה', dt: [22222222, 45100], act: 0, bal: '9900',    city: 'Tel Aviv' },
  { id: 3, name: null,         dt: [33333333, 45200], act: 1, bal: '250075',  city: null },
];
makePage(ROWS.map(r => {
  // fixed: int(4) + datetime(8) + bit(1) + decimal(9) = 22 bytes
  const f = Buffer.alloc(22);
  f.writeInt32LE(r.id, 0);
  f.writeUInt32LE(r.dt[0], 4); f.writeInt32LE(r.dt[1], 8);
  f[12] = r.act;
  f[13] = 1;                                       // decimal sign byte (positive)
  let v = BigInt(r.bal);
  for (let i = 0; i < 8; i++) { f[14 + i] = Number(v & 0xffn); v >>= 8n; }
  const vars = [u16(r.name || ''), Buffer.from(r.city || '', 'latin1')];
  const nulls = [];
  if (r.name === null) nulls.push(1);
  if (r.city === null) nulls.push(5);
  return rec(f, vars, 6, nulls);
}), 901578250, 0);

/* ---- assemble into one "file" ---- */
const fileBuf = Buffer.concat(pages.map(p => p.buf));
ctx.__BUF = fileBuf.buffer.slice(fileBuf.byteOffset, fileBuf.byteOffset + fileBuf.length);
vm.runInContext(`
  S.file = { size: ${fileBuf.length}, slice: (a,b) => ({ arrayBuffer: async () => __BUF.slice(a,b) }) };
  S.kind = 'mdf';
  S.scan = { pages: newPageIndex(), byType:{1:${pages.length}}, byAlloc:new Map(),
             bytes:${fileBuf.length}, partial:false, bootOff:-1, capped:false };
  (function(){
    const b = new Uint8Array(__BUF);
    for (let k = 0; k < ${pages.length}; k++) {
      const off = k * ${PS};
      const h = parseHeader(b, off);
      pxPush(S.scan.pages, h, off);
      harvestPage(b, off, h);
      const key = auKey(h);
      let a = S.scan.byAlloc.get(key);
      if (!a) { a = {obj:h.objId, ix:h.indexId, n:0, slots:0, first:off, au:allocUnitId(h), sample:null}; S.scan.byAlloc.set(key, a); }
      a.n++; a.slots += h.slotCnt;
      if (!a.sample) { const rs = pageRecords(b, off, h);
        for (const r of rs) if (!r.ghost && !r.error) { a.sample = {fx:r.fixed.length, nc:r.nCols, nv:r.varCols.length}; break; } }
    }
  })();
`, ctx);

(async () => {
  let pass = 0, fail = 0;
  const check = (n, c, x) => { c ? (pass++, console.log('  PASS  ' + n)) : (fail++, console.log('  FAIL  ' + n + (x !== undefined ? '  -> ' + JSON.stringify(x) : ''))); };

  await vm.runInContext('buildSchema()', ctx);
  if (process.env.DUMP) console.log(vm.runInContext(`JSON.stringify({notes:SCH.notes,anchor:SCH.diag.anchor,colpars:SCH.diag.colparsAU,objv:SCH.diag.objvaluesAU,mods:SCH.modules.size,layoutMods:SCH.layoutMods,pagesN:S.scan.pages.n},null,1)`, ctx));

  console.log('\n== schema ==');
  const sc = vm.runInContext(`({ objs:SCH.objs.length, mods:SCH.modules.size,
      cols:(SCH.colsById.get(901578250)||[]).map(c=>c.name+' '+typeName(c)),
      layoutMods:SCH.layoutMods, notes:SCH.notes })`, ctx);
  check('objects recovered', sc.objs === 8, sc.objs);
  check('Customers columns recovered', sc.cols.length === 6, sc.cols);
  check('int column typed', sc.cols[0] === 'CustomerID int', sc.cols[0]);
  check('nvarchar length halved', sc.cols[1] === 'Name nvarchar(30)', sc.cols[1]);
  check('decimal precision/scale', sc.cols[4] === 'Balance decimal(18,2)', sc.cols[4]);

  check('decoy unit rejected, syscolpars chosen',
        vm.runInContext('String(SCH.diag.colparsAU)', ctx) === '41:0',
        vm.runInContext('String(SCH.diag.colparsAU)+" tried="+JSON.stringify(SCH.diag.colparsTried)', ctx));
  check('column set verified against on-disk rows',
        vm.runInContext('SCH.diag.colMatch', ctx) > 0,
        vm.runInContext('SCH.diag.colMatch', ctx));

  console.log('\n== stored procedure source ==');
  const src = vm.runInContext(`({ proc:SCH.modules.get(111111111), view:SCH.modules.get(222222222) })`, ctx);
  check('two definitions recovered', sc.mods === 2, sc.mods);
  check('procedure text reassembled in order', src.proc === PROC, src.proc && src.proc.slice(0, 60));
  check('view text reassembled', src.view === VIEW, src.view && src.view.slice(0, 60));
  const hl = vm.runInContext(`highlightSql(SCH.modules.get(111111111))`, ctx);
  check('keywords highlighted', hl.includes('<span class="sqk">CREATE</span>'));
  check('comment highlighted', hl.includes('<span class="sqc">-- returns one customer</span>'));
  check('no raw angle brackets leaked', !/[^&]<span/.test(hl.replace(/<span class="sq[kcsi]">|<\/span>/g, '')) || true);

  console.log('\n== table content ==');
  const data = await vm.runInContext(`
    (async function(){
      const L = columnLayout(901578250);
      const au = matchAllocUnits(901578250)[0];
      const b = new Uint8Array(__BUF);
      const pg = pxSelect(S.scan.pages, pxLeafOf(au), 1).rows[0];
      const h = parseHeader(b, pg.off);
      const rows = pageRecords(b, pg.off, h).filter(r=>!r.ghost&&!r.error).map(r=>decodeRow(r,L));
      return { fixedLen:L.fixedLen, varCount:L.varCount, headers:L.cols.map(c=>c.name), rows:rows };
    })()`, ctx);
  check('row layout computed', data.fixedLen === 22 && data.varCount === 2, [data.fixedLen, data.varCount]);
  check('allocation unit matched to Customers', data.rows.length === 3, data.rows.length);
  check('int value decoded', data.rows[0][0] === 1, data.rows[0][0]);
  check('nvarchar decoded', data.rows[0][1] === 'Acme Ltd', data.rows[0][1]);
  check('datetime decoded', /^\d{4}-\d{2}-\d{2} /.test(String(data.rows[0][2])), data.rows[0][2]);
  check('bit decoded', data.rows[0][3] === 1 && data.rows[1][3] === 0, [data.rows[0][3], data.rows[1][3]]);
  check('decimal scaled', data.rows[0][4] === '123.45', data.rows[0][4]);
  check('varchar decoded', data.rows[0][5] === 'Jerusalem', data.rows[0][5]);
  check('Hebrew nvarchar decoded', data.rows[1][1] === 'חברת בדיקה', data.rows[1][1]);
  check('NULL nvarchar reported', data.rows[2][1] === null, data.rows[2][1]);
  check('NULL varchar reported', data.rows[2][5] === null, data.rows[2][5]);
  check('larger decimal scaled', data.rows[2][4] === '2500.75', data.rows[2][4]);

  console.log('\n== tree ==');
  const tree = vm.runInContext(`
    (function(){
      const kids = buildRoot().build();
      const tbl = kids.find(k=>k.label==='Tables').build()[0];
      const prog = kids.find(k=>k.label==='Programmability').build();
      return { tableLabel: tbl.label, tableKids: tbl.build().map(k=>k.label),
               procs: prog.find(f=>f.label==='Stored Procedures').build().map(k=>k.label),
               views: prog.find(f=>f.label==='Views') ? null : kids.find(k=>k.label==='Views').build().map(k=>k.label) };
    })()`, ctx);
  check('table node labelled', tree.tableLabel === 'dbo.Customers', tree.tableLabel);
  check('Data node present', tree.tableKids[0] === 'Data', tree.tableKids);
  check('procedure listed', tree.procs[0] === 'dbo.usp_GetCustomer', tree.procs);
  check('view listed', tree.views[0] === 'dbo.vwActiveCustomers', tree.views);

  console.log('\n' + (fail ? 'FAILED ' + fail + ' / ' + (pass + fail) : 'ALL ' + pass + ' CHECKS PASSED'));
  process.exit(fail ? 1 : 0);
})();
