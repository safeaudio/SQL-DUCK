const fs = require('fs'), vm = require('vm');

const html = fs.readFileSync((process.env.SQLDUCK || './sqlduck.html'), 'utf8');
const js = html.match(/<script>([\s\S]*?)<\/script>/)[1];

/* --- minimal DOM stub so the top-level wiring does not explode --- */
const mkEl = () => new Proxy({}, {
  get: (t, k) => {
    if (k === 'classList') return { toggle(){}, add(){}, remove(){}, contains(){return false;} };
    if (k === 'options' || k === 'selectedOptions') return { length: 1, 0: { text: '' } };
    if (k === 'style' || k === 'dataset') return {};
    if (k === 'querySelector' || k === 'querySelectorAll') return () => (k === 'querySelectorAll' ? [] : mkEl());
    if (k === 'appendChild' || k === 'add' || k === 'focus' || k === 'click') return () => {};
    if (k === 'value') return '268435456';
    if (k === 'checked') return false;
    if (typeof k === 'string' && k.startsWith('on')) return null;
    return mkEl();
  },
  set: () => true
});
const ctx = {
  console,
  document: { querySelector: () => mkEl(), querySelectorAll: () => [], addEventListener(){}, createElement: () => mkEl() },
  window: { addEventListener(){}, open: () => null },
  location: { protocol: 'file:' },
  FileReader: class { readAsText(){ this.onload && this.onload(); } },
  alert(){}, confirm: () => true,
  setTimeout, clearTimeout, Blob: class {}, URL: { createObjectURL(){}, revokeObjectURL(){} },
  Date, Math, JSON, Map, Set, Uint8Array, DataView, BigInt, Number, String, Object, Array, RegExp, Promise, Error
};
ctx.globalThis = ctx;
vm.createContext(ctx);
vm.runInContext(js, ctx, { filename: 'sqlduck.js' });

/* ---------------------------------------------------------------
   Build a synthetic data page holding sysschobjs-shaped rows using
   a layout NOTHING in the code knows about:
     id      int32   @ 0
     nsid    int32   @ 4
     status  int32   @ 8
     type    char(2) @ 17     <- not the classic offset
     pid     int32   @ 19
     created datetime@ 24
     modified datetime@32
     fixed length 44 (not 40), 11 columns, 1 variable column (name)
   --------------------------------------------------------------- */
const PS = 8192, FIXED = +(process.env.FIXED||44), TYPEOFF = +(process.env.TYPEOFF||17), PIDOFF = +(process.env.PIDOFF||19), NCOLS = 11;

const OBJECTS = [
  { id: 34,        nsid: 4, type: 'S ', pid: 0,  name: 'sysschobjs' },
  { id: 41,        nsid: 4, type: 'S ', pid: 0,  name: 'syscolpars' },
  { id: 5,         nsid: 4, type: 'S ', pid: 0,  name: 'sysrowsets' },
  { id: 7,         nsid: 4, type: 'S ', pid: 0,  name: 'sysallocunits' },
  { id: 54,        nsid: 4, type: 'S ', pid: 0,  name: 'sysidxstats' },
  { id: 901578250, nsid: 1, type: 'U ', pid: 0,  name: 'Customers' },
  { id: 933578364, nsid: 1, type: 'U ', pid: 0,  name: 'Orders' },
  { id: 965578478, nsid: 1, type: 'U ', pid: 0,  name: 'OrderLines' },
  { id: 997578592, nsid: 5, type: 'U ', pid: 0,  name: 'טבלת_לקוחות' },
  { id: 111111111, nsid: 1, type: 'P ', pid: 0,  name: 'usp_GetCustomer' },
  { id: 222222222, nsid: 1, type: 'V ', pid: 0,  name: 'vwActiveOrders' },
  { id: 333333333, nsid: 1, type: 'PK', pid: 901578250, name: 'PK_Customers' },
  { id: 444444444, nsid: 1, type: 'F ', pid: 933578364, name: 'FK_Orders_Customers' },
  { id: 555555555, nsid: 1, type: 'TR', pid: 933578364, name: 'trg_Orders_Audit' },
];

function buildRecord(o) {
  const nameBuf = Buffer.from(o.name, 'utf16le');
  const nullBmp = Math.ceil(NCOLS / 8);                 // 2
  const head = 4 + FIXED + 2 + nullBmp + 2 + 2;         // + var offset array (1 col)
  const rec = Buffer.alloc(head + nameBuf.length);
  rec[0] = 0x30;                                        // null bitmap + variable columns
  rec[1] = 0x00;
  rec.writeUInt16LE(4 + FIXED, 2);
  const f = 4;
  rec.writeInt32LE(o.id, f + 0);
  rec.writeInt32LE(o.nsid, f + 4);
  rec.writeInt32LE(0, f + 8);
  rec.write(o.type, f + TYPEOFF, 'latin1');
  rec.writeInt32LE(o.pid, f + PIDOFF);
  // datetime: ticks-of-day then days-since-1900
  const DT1 = PIDOFF + 4, DT2 = PIDOFF + 12;
  rec.writeUInt32LE(12345678, f + DT1); rec.writeInt32LE(45000, f + DT1 + 4);
  rec.writeUInt32LE(22222222, f + DT2); rec.writeInt32LE(45300, f + DT2 + 4);
  let p = 4 + FIXED;
  rec.writeUInt16LE(NCOLS, p); p += 2;
  rec[p] = 0; rec[p + 1] = 0; p += nullBmp;             // nothing null
  rec.writeUInt16LE(1, p); p += 2;                      // one variable column
  rec.writeUInt16LE(head + nameBuf.length, p); p += 2;  // its end offset
  nameBuf.copy(rec, p);
  return rec;
}

const page = Buffer.alloc(PS);
page[0] = 1; page[1] = 1;                               // headerVersion, type = data
page.writeUInt16LE(0, 4);
page.writeUInt16LE(0, 6);                               // m_indexId
page.writeUInt16LE(FIXED, 14);                          // pminlen
page.writeUInt16LE(OBJECTS.length, 22);                 // slotCnt
page.writeUInt32LE(34, 24);                             // m_objId
page.writeUInt32LE(9, 32); page.writeUInt16LE(1, 36);   // pageId 1:9
let cursor = 96;
OBJECTS.forEach((o, i) => {
  const rec = buildRecord(o);
  rec.copy(page, cursor);
  page.writeUInt16LE(cursor, PS - 2 - i * 2);
  cursor += rec.length;
});
page.writeUInt16LE(PS - 2 - OBJECTS.length * 2 - cursor, 28); // freeCnt
page.writeUInt16LE(cursor, 30);                               // freeData

/* --- feed it to the tool as a one-page "file" --- */
const fileBuf = page;
vm.runInContext(`
  S.file = { size: ${fileBuf.length}, slice: (a,b) => ({ arrayBuffer: async () => __BUF.slice(a,b) }) };
  S.scan = { pages:newPageIndex(), byType:{1:1}, byAlloc:new Map(),
             bytes:${fileBuf.length}, partial:false, bootOff:-1, capped:false };
`, ctx);
ctx.__BUF = fileBuf.buffer.slice(fileBuf.byteOffset, fileBuf.byteOffset + fileBuf.length);
vm.runInContext('pxPush(S.scan.pages, parseHeader(new Uint8Array(__BUF),0), 0);', ctx);

(async () => {
  let pass = 0, fail = 0;
  const check = (name, cond, extra) => {
    if (cond) { pass++; console.log('  PASS  ' + name); }
    else { fail++; console.log('  FAIL  ' + name + (extra !== undefined ? '  -> ' + extra : '')); }
  };

  console.log('\n== page + record parsing ==');
  const parsed = vm.runInContext(`
    (function(){
      const b = new Uint8Array(__BUF);
      const h = parseHeader(b,0);
      const recs = pageRecords(b,0,h);
      return { type:h.type, slots:h.slotCnt, nrecs:recs.length,
               fixedLen:recs[0].fixed.length, nCols:recs[0].nCols, nVar:recs[0].varCols.length,
               firstName: toUtf16(recs[0].varCols[0].data,0,recs[0].varCols[0].data.length),
               hebrew: toUtf16(recs[8].varCols[0].data,0,recs[8].varCols[0].data.length) };
    })()`, ctx);
  check('page recognised as data', parsed.type === 1, parsed.type);
  check('all ' + OBJECTS.length + ' slots parsed', parsed.nrecs === OBJECTS.length, parsed.nrecs);
  check('fixed length read as '+FIXED, parsed.fixedLen === FIXED, parsed.fixedLen);
  check('column count read as 11', parsed.nCols === 11, parsed.nCols);
  check('name decoded', parsed.firstName === 'sysschobjs', parsed.firstName);
  check('Hebrew name decoded', parsed.hebrew === 'טבלת_לקוחות', parsed.hebrew);

  console.log('\n== adaptive offset discovery ==');
  const found = vm.runInContext(`
    (function(){
      const b = new Uint8Array(__BUF);
      const h = parseHeader(b,0);
      harvestPage(b,0,h);
      const au = findSchobjsAU();
      return { auFound: !!au, names: au ? au.names.length : 0,
               typeOff: (function(){
                 const recs = pageRecords(b,0,h).filter(r=>!r.error);
                 const t = findObjTypeOffset(recs);
                 return t ? t.off + ':' + t.enc : 'none';
               })() };
    })()`, ctx);
  check('sysschobjs allocation unit identified', found.auFound === true);
  check('type code located at offset '+TYPEOFF, found.typeOff === TYPEOFF+':a', found.typeOff);

  console.log('\n== end-to-end object load ==');
  await vm.runInContext(`buildSchema()`, ctx);
  const out = vm.runInContext(`
    ({ n: SCH.objs.length, ok: SCH.ok,
       tables: SCH.objs.filter(o=>o.type==='U ').map(o=>schemaOf(o)+'.'+o.name),
       procs:  SCH.objs.filter(o=>o.type==='P ').map(o=>o.name),
       views:  SCH.objs.filter(o=>o.type==='V ').map(o=>o.name),
       fkParent: (function(){ const f=SCH.objs.find(o=>o.name==='FK_Orders_Customers');
                              return f && SCH.byId.has(f.pid) ? SCH.byId.get(f.pid).name : null; })(),
       layout: SCH.layoutObjs })`, ctx);
  check('schema marked usable', out.ok === true);
  check('all 14 objects recovered', out.n === 14, out.n);
  check('user tables found', out.tables.length === 4, JSON.stringify(out.tables));
  check('dbo schema resolved', out.tables.includes('dbo.Customers'), JSON.stringify(out.tables));
  check('procedure classified', out.procs[0] === 'usp_GetCustomer', JSON.stringify(out.procs));
  check('view classified', out.views[0] === 'vwActiveOrders', JSON.stringify(out.views));
  check('foreign key linked to its parent table', out.fkParent === 'Orders', out.fkParent);
  check('schema_id offset derived as 4', out.layout.nsOff === 4, out.layout.nsOff);
  check('parent offset derived as '+PIDOFF, out.layout.pidOff === PIDOFF, out.layout.pidOff);
  check('two datetime columns located', out.layout.dtOffs.length === 2, JSON.stringify(out.layout.dtOffs));

  console.log('\n== tree rendering (headless) ==');
  const tree = vm.runInContext(`
    (function(){
      const root = buildRoot();
      const kids = root.build();
      const tbl  = kids.find(k=>k.label==='Tables');
      return { root: root.label, folders: kids.map(k=>k.label),
               tableCount: tbl ? tbl.count : -1,
               firstTable: tbl ? tbl.build()[0].label : null };
    })()`, ctx);
  check('Tables folder present', tree.folders.includes('Tables'), JSON.stringify(tree.folders));
  check('Tables node reports 4', tree.tableCount === 4, tree.tableCount);
  check('first table node labelled', tree.firstTable === 'dbo.Customers', tree.firstTable);

  console.log('\n' + (fail ? 'FAILED ' + fail + ' / ' + (pass + fail) : 'ALL ' + pass + ' CHECKS PASSED'));
  process.exit(fail ? 1 : 0);
})();
